﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DB_Project
{
    public partial class GYM_O : Form
    {
        public static GYM_O instance;
        public string userid;
        public int useri;
        public GYM_O()
        {
            InitializeComponent();
            instance = this;
        }

 
        private void gunaButton1_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionString);

            conn.Open();


            if (textBox1.Text != "" && textBox2.Text != "")
            {
                string query = "INSERT INTO OWNS_REQUEST VALUES('" + useri + "', '" + textBox1.Text + "', '" + textBox2.Text + "')";
                SqlCommand cm = new SqlCommand(query, conn);

                cm = new SqlCommand(query, conn);

                cm.ExecuteNonQuery();

                MessageBox.Show("Requested!!");
            }
            conn.Close();
        }
    }

}
