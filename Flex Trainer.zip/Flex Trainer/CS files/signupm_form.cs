﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DB_Project
{
    public partial class signupm_form : Form
    {
        public signupm_form()
        {
            InitializeComponent();
            this.Size = new System.Drawing.Size(450, 660);
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionString);

            conn.Open();

            string name = NameT.Text;
            string Uname = UnameT.Text;
            string pass = passT.Text;
            string email = EmailT.Text;
            string cnic = CNICT.Text;
            string gender = GenderT.Text;
            string age = AgeT.Text;
            string contact = ContactT.Text;
            string add = AddT.Text;


            string query = "INSERT INTO USER1 VALUES(GETDATE(),'" + Uname + "', '" + pass + "','" + email + "','" + name + "','" + cnic + "','MEMBER')";
            SqlCommand cm = new SqlCommand(query, conn);
            cm.ExecuteNonQuery();

            query = "SELECT MAX(USERID) FROM USER1";
            cm = new SqlCommand(query, conn);
            object o1 = cm.ExecuteScalar();

            int id = Int32.Parse(o1.ToString());
            
            query = "INSERT INTO MEMBER1 VALUES('" + id + "', '" + comboBox1.Text + "','" + add + "','" + contact + "',GETDATE(),'" + Int32.Parse(age) + "','" + gender + "',NULL,NULL,NULL)";
            cm = new SqlCommand(query, conn);
            cm.ExecuteNonQuery();

            conn.Close();

            MessageBox.Show("Signed up!!");

            loging_form l1 = new loging_form();
            this.Hide();
            l1.Show();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
