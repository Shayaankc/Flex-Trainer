﻿namespace DB_Project
{
    partial class member_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(member_main));
            this.panel1 = new System.Windows.Forms.Panel();
            this.TOP_BUTTON = new System.Windows.Forms.PictureBox();
            this.side_bar = new System.Windows.Forms.FlowLayoutPanel();
            this.WPP = new System.Windows.Forms.Panel();
            this.WKB = new System.Windows.Forms.Button();
            this.BTP = new System.Windows.Forms.Panel();
            this.BTB = new System.Windows.Forms.Button();
            this.DPP = new System.Windows.Forms.Panel();
            this.DPB = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.FBP = new System.Windows.Forms.Panel();
            this.FBB = new System.Windows.Forms.Button();
            this.transitiontimer = new System.Windows.Forms.Timer(this.components);
            this.main_panel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Flex = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TOP_BUTTON)).BeginInit();
            this.side_bar.SuspendLayout();
            this.WPP.SuspendLayout();
            this.BTP.SuspendLayout();
            this.DPP.SuspendLayout();
            this.panel3.SuspendLayout();
            this.FBP.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gold;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(443, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1230, 68);
            this.panel1.TabIndex = 0;
            // 
            // TOP_BUTTON
            // 
            this.TOP_BUTTON.BackColor = System.Drawing.Color.Gold;
            this.TOP_BUTTON.Image = ((System.Drawing.Image)(resources.GetObject("TOP_BUTTON.Image")));
            this.TOP_BUTTON.Location = new System.Drawing.Point(11, 3);
            this.TOP_BUTTON.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.TOP_BUTTON.Name = "TOP_BUTTON";
            this.TOP_BUTTON.Size = new System.Drawing.Size(65, 65);
            this.TOP_BUTTON.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.TOP_BUTTON.TabIndex = 1;
            this.TOP_BUTTON.TabStop = false;
            this.TOP_BUTTON.Click += new System.EventHandler(this.TOP_BUTTON_Click);
            // 
            // side_bar
            // 
            this.side_bar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(24)))), ((int)(((byte)(29)))));
            this.side_bar.Controls.Add(this.WPP);
            this.side_bar.Controls.Add(this.BTP);
            this.side_bar.Controls.Add(this.DPP);
            this.side_bar.Controls.Add(this.panel3);
            this.side_bar.Controls.Add(this.FBP);
            this.side_bar.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.side_bar.Location = new System.Drawing.Point(0, 67);
            this.side_bar.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.side_bar.Name = "side_bar";
            this.side_bar.Size = new System.Drawing.Size(443, 1009);
            this.side_bar.TabIndex = 1;
            // 
            // WPP
            // 
            this.WPP.Controls.Add(this.WKB);
            this.WPP.Location = new System.Drawing.Point(2, 3);
            this.WPP.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.WPP.Name = "WPP";
            this.WPP.Size = new System.Drawing.Size(444, 163);
            this.WPP.TabIndex = 3;
            // 
            // WKB
            // 
            this.WKB.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.WKB.Font = new System.Drawing.Font("Sitka Heading", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WKB.ForeColor = System.Drawing.Color.White;
            this.WKB.Image = ((System.Drawing.Image)(resources.GetObject("WKB.Image")));
            this.WKB.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.WKB.Location = new System.Drawing.Point(-34, -15);
            this.WKB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.WKB.Name = "WKB";
            this.WKB.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.WKB.Size = new System.Drawing.Size(516, 196);
            this.WKB.TabIndex = 2;
            this.WKB.Text = "Workout Plan";
            this.WKB.UseVisualStyleBackColor = false;
            this.WKB.Click += new System.EventHandler(this.WKB_Click);
            // 
            // BTP
            // 
            this.BTP.Controls.Add(this.BTB);
            this.BTP.Location = new System.Drawing.Point(2, 172);
            this.BTP.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.BTP.Name = "BTP";
            this.BTP.Size = new System.Drawing.Size(444, 163);
            this.BTP.TabIndex = 5;
            // 
            // BTB
            // 
            this.BTB.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BTB.Font = new System.Drawing.Font("Sitka Heading", 10.125F, System.Drawing.FontStyle.Bold);
            this.BTB.ForeColor = System.Drawing.Color.White;
            this.BTB.Image = ((System.Drawing.Image)(resources.GetObject("BTB.Image")));
            this.BTB.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTB.Location = new System.Drawing.Point(-34, -23);
            this.BTB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.BTB.Name = "BTB";
            this.BTB.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.BTB.Size = new System.Drawing.Size(516, 215);
            this.BTB.TabIndex = 2;
            this.BTB.Text = "Book Trainer";
            this.BTB.UseVisualStyleBackColor = false;
            this.BTB.Click += new System.EventHandler(this.BTB_Click);
            // 
            // DPP
            // 
            this.DPP.Controls.Add(this.DPB);
            this.DPP.Location = new System.Drawing.Point(2, 341);
            this.DPP.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.DPP.Name = "DPP";
            this.DPP.Size = new System.Drawing.Size(444, 163);
            this.DPP.TabIndex = 4;
            // 
            // DPB
            // 
            this.DPB.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DPB.Font = new System.Drawing.Font("Sitka Heading", 10.125F, System.Drawing.FontStyle.Bold);
            this.DPB.ForeColor = System.Drawing.Color.White;
            this.DPB.Image = ((System.Drawing.Image)(resources.GetObject("DPB.Image")));
            this.DPB.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DPB.Location = new System.Drawing.Point(-34, -23);
            this.DPB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.DPB.Name = "DPB";
            this.DPB.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.DPB.Size = new System.Drawing.Size(516, 204);
            this.DPB.TabIndex = 2;
            this.DPB.Text = "Diet Plan";
            this.DPB.UseVisualStyleBackColor = false;
            this.DPB.Click += new System.EventHandler(this.DPB_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button1);
            this.panel3.Location = new System.Drawing.Point(2, 510);
            this.panel3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(444, 163);
            this.panel3.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Font = new System.Drawing.Font("Sitka Heading", 10.125F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(-34, -23);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(516, 215);
            this.button1.TabIndex = 2;
            this.button1.Text = "Gym";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FBP
            // 
            this.FBP.Controls.Add(this.FBB);
            this.FBP.Location = new System.Drawing.Point(2, 679);
            this.FBP.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.FBP.Name = "FBP";
            this.FBP.Size = new System.Drawing.Size(444, 163);
            this.FBP.TabIndex = 4;
            // 
            // FBB
            // 
            this.FBB.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FBB.Font = new System.Drawing.Font("Sitka Heading", 10.125F, System.Drawing.FontStyle.Bold);
            this.FBB.ForeColor = System.Drawing.Color.White;
            this.FBB.Image = ((System.Drawing.Image)(resources.GetObject("FBB.Image")));
            this.FBB.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FBB.Location = new System.Drawing.Point(-34, -23);
            this.FBB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.FBB.Name = "FBB";
            this.FBB.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.FBB.Size = new System.Drawing.Size(516, 215);
            this.FBB.TabIndex = 2;
            this.FBB.Text = "Feedback";
            this.FBB.UseVisualStyleBackColor = false;
            this.FBB.Click += new System.EventHandler(this.FBB_Click);
            // 
            // transitiontimer
            // 
            this.transitiontimer.Interval = 10;
            this.transitiontimer.Tick += new System.EventHandler(this.transitiontimer_Tick);
            // 
            // main_panel
            // 
            this.main_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.main_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.main_panel.Location = new System.Drawing.Point(443, 0);
            this.main_panel.Name = "main_panel";
            this.main_panel.Size = new System.Drawing.Size(1230, 1076);
            this.main_panel.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.TOP_BUTTON);
            this.panel2.Controls.Add(this.Flex);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(443, 1076);
            this.panel2.TabIndex = 5;
            // 
            // Flex
            // 
            this.Flex.AutoSize = true;
            this.Flex.BackColor = System.Drawing.Color.Gold;
            this.Flex.Font = new System.Drawing.Font("Sitka Heading", 19.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Flex.Location = new System.Drawing.Point(-64, -5);
            this.Flex.Name = "Flex";
            this.Flex.Size = new System.Drawing.Size(520, 73);
            this.Flex.TabIndex = 2;
            this.Flex.Text = "           FLEX TRAINER";
            // 
            // member_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1673, 1076);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.side_bar);
            this.Controls.Add(this.main_panel);
            this.Controls.Add(this.panel2);
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "member_main";
            this.Text = "member_main";
            this.Load += new System.EventHandler(this.member_main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TOP_BUTTON)).EndInit();
            this.side_bar.ResumeLayout(false);
            this.WPP.ResumeLayout(false);
            this.BTP.ResumeLayout(false);
            this.DPP.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.FBP.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox TOP_BUTTON;
        private System.Windows.Forms.FlowLayoutPanel side_bar;
        private System.Windows.Forms.Button WKB;
        private System.Windows.Forms.Panel WPP;
        private System.Windows.Forms.Panel DPP;
        private System.Windows.Forms.Button DPB;
        private System.Windows.Forms.Panel BTP;
        private System.Windows.Forms.Button BTB;
        private System.Windows.Forms.Panel FBP;
        private System.Windows.Forms.Button FBB;
        private System.Windows.Forms.Timer transitiontimer;
        private System.Windows.Forms.Panel main_panel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label Flex;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button1;
    }
}