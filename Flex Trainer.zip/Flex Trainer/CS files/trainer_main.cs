﻿using dbproject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Project
{
    public partial class trainer_main : Form
    {
        Workout_M Workout_M;
        memberappointment book_Trainer_M;
        memberfeedback memberfeedback;
        memberdiet memberdiet;

        public static trainer_main instance;
        public string userid;
        public trainer_main()
        {
            InitializeComponent();
            this.Size = new System.Drawing.Size(800, 590);
            instance = this;
        }

        public void loadform(object Form)
        { 
            if(this.main_panel.Controls.Count > 0) 
            {
                Form previousForm = this.main_panel.Controls[0] as Form;
                previousForm.Close();
            }
            Form f = Form as Form;
            f.TopLevel = false;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.main_panel.Controls.Add(f);
            this.main_panel.Tag = f;
            f.Show();
        }

        private void member_main_Load(object sender, EventArgs e)
        {

        }

        bool sidbarexpand = true;
        private void transitiontimer_Tick(object sender, EventArgs e)
        {
            if (sidbarexpand)
            {
                side_bar.Width -= 7;

                if (side_bar.Width <= 70)
                {
                    sidbarexpand = false;
                    transitiontimer.Stop();

                    DPP.Width = side_bar.Width;
                    BTP.Width = side_bar.Width;
                    FBP.Width = side_bar.Width;
                }
            }
            else 
            {
                side_bar.Width += 7;

                if (side_bar.Width >= 200)
                {
                    sidbarexpand = true;
                    transitiontimer.Stop();

                    DPP.Width = side_bar.Width;
                    BTP.Width = side_bar.Width;
                    FBP.Width = side_bar.Width;
                }
            }
        }

        private void TOP_BUTTON_Click(object sender, EventArgs e)
        {
            transitiontimer.Start();

        }

        private void FBB_Click(object sender, EventArgs e)
        {
            DietPlan_T t1 = new DietPlan_T();
            DietPlan_T.instance.userid = userid;
            DietPlan_T.instance.useri = Int32.Parse(userid);
            DietPlan_T.instance.membergridview();
            DietPlan_T.instance.currlabel();
            loadform(t1);
        }

        
        private void BTB_Click(object sender, EventArgs e)
        {
            Feedback_T t1 = new Feedback_T();
            Feedback_T.instance.userid = userid;
            Feedback_T.instance.useri = Int32.Parse(userid);
            Feedback_T.instance.membergridview();
            Feedback_T.instance.currlabel();
            loadform(t1);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            Appointment_T t1 = new Appointment_T();
            Appointment_T.instance.userid = userid;
            Appointment_T.instance.useri = Int32.Parse(userid);
            Appointment_T.instance.membergridview();
            loadform(t1);
        }

        private void DPB_Click(object sender, EventArgs e)
        {
            WorkoutPlan_T t1 = new WorkoutPlan_T();
            WorkoutPlan_T.instance.userid = userid;
            WorkoutPlan_T.instance.useri = Int32.Parse(userid);
            WorkoutPlan_T.instance.membergridview();
            WorkoutPlan_T.instance.currlabel();
            loadform(t1);
        }

        private void side_bar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)  //join gym
        {
            Gym_T t1 = new Gym_T();
            Gym_T.instance.userid = userid;
            Gym_T.instance.useri = Int32.Parse(userid);
            Gym_T.instance.membergridview();
            Gym_T.instance.currlabel();
            loadform(t1);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            T_report t1 = new T_report();
            loadform(t1);
        }
    }
}
