﻿using dbproject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DB_Project
{
    public partial class admin_main : Form
    {
        Workout_M Workout_M;
        memberappointment book_Trainer_M;
        memberfeedback memberfeedback;
        memberdiet memberdiet;

        public static admin_main instance;
        public string userid;
        public admin_main()
        {
            InitializeComponent();
            this.Size = new System.Drawing.Size(800, 590);
            instance = this;
        }

        public void loadform(object Form)
        { 
            if(this.main_panel.Controls.Count > 0) 
            {
                Form previousForm = this.main_panel.Controls[0] as Form;
                previousForm.Close();
            }
            Form f = Form as Form;
            f.TopLevel = false;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.main_panel.Controls.Add(f);
            this.main_panel.Tag = f;
            f.Show();
        }

        private void member_main_Load(object sender, EventArgs e)
        {

        }

        bool sidbarexpand = true;
        private void transitiontimer_Tick(object sender, EventArgs e)
        {
            if (sidbarexpand)
            {
                side_bar.Width -= 7;

                if (side_bar.Width <= 70)
                {
                    sidbarexpand = false;
                    transitiontimer.Stop();

                    DPP.Width = side_bar.Width;
                    FBP.Width = side_bar.Width;
                }
            }
            else 
            {
                side_bar.Width += 7;

                if (side_bar.Width >= 200)
                {
                    sidbarexpand = true;
                    transitiontimer.Stop();

                    DPP.Width = side_bar.Width;
                    FBP.Width = side_bar.Width;
                }
            }
        }

        private void TOP_BUTTON_Click(object sender, EventArgs e)
        {
            transitiontimer.Start();

        }

        private void FBB_Click(object sender, EventArgs e)
        {
            RM_A a1 = new RM_A();
            RM_A.instance.userid = userid;
            RM_A.instance.useri = Int32.Parse(userid);
            RM_A.instance.membergridview();
            loadform(a1);
        }

        
        private void BTB_Click(object sender, EventArgs e)
        {
            loadform(new memberappointment());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            POG_A a1 = new POG_A();
            POG_A.instance.userid = userid;
            POG_A.instance.useri = Int32.Parse(userid);
            loadform(a1);
        }

        private void DPB_Click(object sender, EventArgs e)
        {
            GYM_A a1 = new GYM_A();
            GYM_A.instance.userid = userid;
            GYM_A.instance.useri = Int32.Parse(userid);
            GYM_A.instance.membergridview();
            loadform(a1);
        }
    }
}
