﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Reflection.Emit;

namespace dbproject
{
    public partial class Workout_M : Form
    {
        public static Workout_M instance;
        public string userid;
        public int useri;
        public Workout_M()
        {
            InitializeComponent();
            instance = this;
        }
       
        public void membergridview()
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();

            string query1 = "SELECT WORKOUT_PLAN.WP_ID AS ID,WORKOUT_PLAN.NAME1 AS NAME,WORKOUT_PLAN.LEVEL1 AS DIFFICULTY,WORKOUT_PLAN.DESCRIPTION1 AS DESCRIPTION FROM WORKOUT_PLAN JOIN TRAINER ON CREATED_BY = TRAINER.TRAINER_ID JOIN WORKS_AT ON TRAINER.TRAINER_ID = WORKS_AT.TRAINER_ID JOIN GYM ON GYM.GYM_ID = WORKS_AT.GYM_ID JOIN MEMBER1 ON MEMBER1.GYM_ID = GYM.GYM_ID WHERE MEMBER1.MEMBER_ID = +'" + useri + "'";
            SqlDataAdapter da1 = new SqlDataAdapter(query1, conn);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);

            string query2 = "SELECT WORKOUT_PLAN.WP_ID AS ID,WORKOUT_PLAN.NAME1 AS NAME,WORKOUT_PLAN.LEVEL1 AS DIFFICULTY,WORKOUT_PLAN.DESCRIPTION1 AS DESCRIPTION FROM WORKOUT_PLAN JOIN MEMBER1 ON CREATED_BY = MEMBER1.MEMBER_ID WHERE MEMBER1.MEMBER_ID = +'" + useri + "'";
            SqlDataAdapter da2 = new SqlDataAdapter(query2, conn);
            DataTable dt2 = new DataTable();
            da2.Fill(dt2);

            DataTable mergedDataTable = dt1.Clone();
            mergedDataTable.Merge(dt1);
            mergedDataTable.Merge(dt2);

            Workout_Mdatagridview.DataSource = mergedDataTable;
            conn.Close();
        }


        /*  private void button2_Click(object sender, EventArgs e)
          {
              this.Hide();
              member m = new member();
              member.instance.userid = userid;

              m.Show();
          }
        */


        private void Workout_M_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        public void workoutlabel()
        {
            string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";

            SqlConnection conn = new SqlConnection(connectionString);

            conn.Open();

            string query = "SELECT WORKOUT_PLAN.WP_ID,WORKOUT_PLAN.NAME1,WORKOUT_PLAN.LEVEL1 FROM WORKOUT_PLAN JOIN MEMBER1 ON WORKOUT_PLAN.WP_ID = MEMBER1.WP_ID WHERE MEMBER1.MEMBER_ID =  +'" + Int32.Parse(userid) + "' ";
            SqlCommand cm = new SqlCommand(query, conn);


            SqlDataReader reader = cm.ExecuteReader();

            if (reader.Read())
            {
                int workoutPlanId = reader.GetInt32(reader.GetOrdinal("WP_ID"));
                string workoutPlanName = reader.GetString(reader.GetOrdinal("NAME1"));
                int workoutPlanLevel = reader.GetInt32(reader.GetOrdinal("LEVEL1"));

                label3.Text = $"Current Workout Plan: ID - {workoutPlanId}, Name - {workoutPlanName}, Level - {workoutPlanLevel}";
            }
            else
            {
                label3.Text = "The User Does Not Have A Workout Plan Yet!";
            }

            reader.Close();
            conn.Close();

        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            
                SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
                conn.Open();
                SqlCommand cm;


                string choice = textBox1.Text;
                if (choice != "")
                {
                    int c = Int32.Parse(choice);

                    string query = "UPDATE MEMBER1 SET WP_ID = +'" + c + "' WHERE MEMBER_ID = +'" + useri + "'";
                    cm = new SqlCommand(query, conn);
                    cm.ExecuteNonQuery();
                    conn.Close();

                    MessageBox.Show("Updated!!");
                }
           

        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            membercreatework m1 = new membercreatework();
            membercreatework.instance.userid = userid;
            membercreatework.instance.useri = useri;
            m1.Show();
        }
    }
}
