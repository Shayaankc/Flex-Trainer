﻿namespace DB_Project
{
    partial class signupT_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(signupT_form));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.NameT = new Guna.UI.WinForms.GunaTextBox();
            this.UnameT = new Guna.UI.WinForms.GunaTextBox();
            this.passT = new Guna.UI.WinForms.GunaTextBox();
            this.EmailT = new Guna.UI.WinForms.GunaTextBox();
            this.CNICT = new Guna.UI.WinForms.GunaTextBox();
            this.GenderT = new Guna.UI.WinForms.GunaTextBox();
            this.ContactT = new Guna.UI.WinForms.GunaTextBox();
            this.AddT = new Guna.UI.WinForms.GunaTextBox();
            this.Button1 = new Guna.UI.WinForms.GunaButton();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel3 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel5 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel6 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel8 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel9 = new Guna.UI.WinForms.GunaLabel();
            this.SpecT = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel7 = new Guna.UI.WinForms.GunaLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Gold;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-2, -3);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(434, 625);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // NameT
            // 
            this.NameT.BackColor = System.Drawing.Color.Transparent;
            this.NameT.BaseColor = System.Drawing.Color.Black;
            this.NameT.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.NameT.BorderSize = 3;
            this.NameT.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.NameT.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.NameT.FocusedBorderColor = System.Drawing.Color.Black;
            this.NameT.FocusedForeColor = System.Drawing.Color.White;
            this.NameT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.NameT.ForeColor = System.Drawing.Color.White;
            this.NameT.Location = new System.Drawing.Point(204, 137);
            this.NameT.Margin = new System.Windows.Forms.Padding(2);
            this.NameT.Name = "NameT";
            this.NameT.PasswordChar = '\0';
            this.NameT.SelectedText = "";
            this.NameT.Size = new System.Drawing.Size(199, 32);
            this.NameT.TabIndex = 2;
            // 
            // UnameT
            // 
            this.UnameT.BackColor = System.Drawing.Color.Transparent;
            this.UnameT.BaseColor = System.Drawing.Color.Black;
            this.UnameT.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.UnameT.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.UnameT.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.UnameT.FocusedBorderColor = System.Drawing.Color.Black;
            this.UnameT.FocusedForeColor = System.Drawing.Color.White;
            this.UnameT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.UnameT.ForeColor = System.Drawing.Color.White;
            this.UnameT.Location = new System.Drawing.Point(204, 179);
            this.UnameT.Margin = new System.Windows.Forms.Padding(2);
            this.UnameT.Name = "UnameT";
            this.UnameT.PasswordChar = '\0';
            this.UnameT.SelectedText = "";
            this.UnameT.Size = new System.Drawing.Size(199, 32);
            this.UnameT.TabIndex = 3;
            // 
            // passT
            // 
            this.passT.BackColor = System.Drawing.Color.Transparent;
            this.passT.BaseColor = System.Drawing.Color.Black;
            this.passT.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.passT.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.passT.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.passT.FocusedBorderColor = System.Drawing.Color.Black;
            this.passT.FocusedForeColor = System.Drawing.Color.White;
            this.passT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.passT.ForeColor = System.Drawing.Color.White;
            this.passT.Location = new System.Drawing.Point(204, 222);
            this.passT.Margin = new System.Windows.Forms.Padding(2);
            this.passT.Name = "passT";
            this.passT.PasswordChar = '\0';
            this.passT.SelectedText = "";
            this.passT.Size = new System.Drawing.Size(199, 32);
            this.passT.TabIndex = 4;
            // 
            // EmailT
            // 
            this.EmailT.BackColor = System.Drawing.Color.Transparent;
            this.EmailT.BaseColor = System.Drawing.Color.Black;
            this.EmailT.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.EmailT.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.EmailT.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.EmailT.FocusedBorderColor = System.Drawing.Color.Black;
            this.EmailT.FocusedForeColor = System.Drawing.Color.White;
            this.EmailT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.EmailT.ForeColor = System.Drawing.Color.White;
            this.EmailT.Location = new System.Drawing.Point(204, 267);
            this.EmailT.Margin = new System.Windows.Forms.Padding(2);
            this.EmailT.Name = "EmailT";
            this.EmailT.PasswordChar = '\0';
            this.EmailT.SelectedText = "";
            this.EmailT.Size = new System.Drawing.Size(199, 32);
            this.EmailT.TabIndex = 5;
            // 
            // CNICT
            // 
            this.CNICT.BackColor = System.Drawing.Color.Transparent;
            this.CNICT.BaseColor = System.Drawing.Color.Black;
            this.CNICT.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.CNICT.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CNICT.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.CNICT.FocusedBorderColor = System.Drawing.Color.Black;
            this.CNICT.FocusedForeColor = System.Drawing.Color.White;
            this.CNICT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.CNICT.ForeColor = System.Drawing.Color.White;
            this.CNICT.Location = new System.Drawing.Point(204, 314);
            this.CNICT.Margin = new System.Windows.Forms.Padding(2);
            this.CNICT.Name = "CNICT";
            this.CNICT.PasswordChar = '\0';
            this.CNICT.SelectedText = "";
            this.CNICT.Size = new System.Drawing.Size(199, 32);
            this.CNICT.TabIndex = 6;
            // 
            // GenderT
            // 
            this.GenderT.BackColor = System.Drawing.Color.Transparent;
            this.GenderT.BaseColor = System.Drawing.Color.Black;
            this.GenderT.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.GenderT.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.GenderT.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.GenderT.FocusedBorderColor = System.Drawing.Color.Black;
            this.GenderT.FocusedForeColor = System.Drawing.Color.White;
            this.GenderT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GenderT.ForeColor = System.Drawing.Color.White;
            this.GenderT.Location = new System.Drawing.Point(204, 362);
            this.GenderT.Margin = new System.Windows.Forms.Padding(2);
            this.GenderT.Name = "GenderT";
            this.GenderT.PasswordChar = '\0';
            this.GenderT.SelectedText = "";
            this.GenderT.Size = new System.Drawing.Size(199, 32);
            this.GenderT.TabIndex = 7;
            // 
            // ContactT
            // 
            this.ContactT.BaseColor = System.Drawing.Color.Black;
            this.ContactT.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ContactT.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ContactT.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ContactT.FocusedBorderColor = System.Drawing.Color.Black;
            this.ContactT.FocusedForeColor = System.Drawing.Color.White;
            this.ContactT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ContactT.ForeColor = System.Drawing.Color.White;
            this.ContactT.Location = new System.Drawing.Point(204, 457);
            this.ContactT.Margin = new System.Windows.Forms.Padding(2);
            this.ContactT.Name = "ContactT";
            this.ContactT.PasswordChar = '\0';
            this.ContactT.SelectedText = "";
            this.ContactT.Size = new System.Drawing.Size(199, 32);
            this.ContactT.TabIndex = 9;
            // 
            // AddT
            // 
            this.AddT.BackColor = System.Drawing.Color.Transparent;
            this.AddT.BaseColor = System.Drawing.Color.Black;
            this.AddT.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AddT.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.AddT.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AddT.FocusedBorderColor = System.Drawing.Color.Black;
            this.AddT.FocusedForeColor = System.Drawing.Color.White;
            this.AddT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.AddT.ForeColor = System.Drawing.Color.White;
            this.AddT.Location = new System.Drawing.Point(204, 501);
            this.AddT.Margin = new System.Windows.Forms.Padding(2);
            this.AddT.Name = "AddT";
            this.AddT.PasswordChar = '\0';
            this.AddT.SelectedText = "";
            this.AddT.Size = new System.Drawing.Size(199, 32);
            this.AddT.TabIndex = 10;
            // 
            // Button1
            // 
            this.Button1.AnimationHoverSpeed = 0.07F;
            this.Button1.AnimationSpeed = 0.03F;
            this.Button1.BackColor = System.Drawing.Color.Transparent;
            this.Button1.BaseColor = System.Drawing.Color.Gold;
            this.Button1.BorderColor = System.Drawing.Color.Gold;
            this.Button1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.Button1.FocusedColor = System.Drawing.Color.Empty;
            this.Button1.Font = new System.Drawing.Font("Sitka Heading", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button1.ForeColor = System.Drawing.Color.Black;
            this.Button1.Image = null;
            this.Button1.ImageSize = new System.Drawing.Size(20, 20);
            this.Button1.Location = new System.Drawing.Point(120, 551);
            this.Button1.Margin = new System.Windows.Forms.Padding(2);
            this.Button1.Name = "Button1";
            this.Button1.OnHoverBaseColor = System.Drawing.Color.Black;
            this.Button1.OnHoverBorderColor = System.Drawing.Color.Gold;
            this.Button1.OnHoverForeColor = System.Drawing.Color.Gold;
            this.Button1.OnHoverImage = null;
            this.Button1.OnPressedColor = System.Drawing.Color.Black;
            this.Button1.Size = new System.Drawing.Size(192, 28);
            this.Button1.TabIndex = 11;
            this.Button1.Text = "Sign Up";
            this.Button1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.gunaLabel1.Font = new System.Drawing.Font("Sitka Heading", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.gunaLabel1.Location = new System.Drawing.Point(98, 137);
            this.gunaLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(105, 28);
            this.gunaLabel1.TabIndex = 12;
            this.gunaLabel1.Text = "Full Name:";
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.gunaLabel2.Font = new System.Drawing.Font("Sitka Heading", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel2.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.gunaLabel2.Location = new System.Drawing.Point(98, 179);
            this.gunaLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(102, 28);
            this.gunaLabel2.TabIndex = 13;
            this.gunaLabel2.Text = "Username:";
            // 
            // gunaLabel3
            // 
            this.gunaLabel3.AutoSize = true;
            this.gunaLabel3.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.gunaLabel3.Font = new System.Drawing.Font("Sitka Heading", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel3.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.gunaLabel3.Location = new System.Drawing.Point(102, 222);
            this.gunaLabel3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.gunaLabel3.Name = "gunaLabel3";
            this.gunaLabel3.Size = new System.Drawing.Size(99, 28);
            this.gunaLabel3.TabIndex = 14;
            this.gunaLabel3.Text = "Password:";
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.AutoSize = true;
            this.gunaLabel4.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.gunaLabel4.Font = new System.Drawing.Font("Sitka Heading", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel4.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.gunaLabel4.Location = new System.Drawing.Point(134, 267);
            this.gunaLabel4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(68, 28);
            this.gunaLabel4.TabIndex = 15;
            this.gunaLabel4.Text = "Email:";
            // 
            // gunaLabel5
            // 
            this.gunaLabel5.AutoSize = true;
            this.gunaLabel5.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.gunaLabel5.Font = new System.Drawing.Font("Sitka Heading", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel5.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.gunaLabel5.Location = new System.Drawing.Point(141, 314);
            this.gunaLabel5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.gunaLabel5.Name = "gunaLabel5";
            this.gunaLabel5.Size = new System.Drawing.Size(60, 28);
            this.gunaLabel5.TabIndex = 16;
            this.gunaLabel5.Text = "CNIC:";
            // 
            // gunaLabel6
            // 
            this.gunaLabel6.AutoSize = true;
            this.gunaLabel6.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.gunaLabel6.Font = new System.Drawing.Font("Sitka Heading", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel6.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.gunaLabel6.Location = new System.Drawing.Point(122, 362);
            this.gunaLabel6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.gunaLabel6.Name = "gunaLabel6";
            this.gunaLabel6.Size = new System.Drawing.Size(79, 28);
            this.gunaLabel6.TabIndex = 17;
            this.gunaLabel6.Text = "Gender:";
            // 
            // gunaLabel8
            // 
            this.gunaLabel8.AutoSize = true;
            this.gunaLabel8.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.gunaLabel8.Font = new System.Drawing.Font("Sitka Heading", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel8.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.gunaLabel8.Location = new System.Drawing.Point(120, 457);
            this.gunaLabel8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.gunaLabel8.Name = "gunaLabel8";
            this.gunaLabel8.Size = new System.Drawing.Size(82, 28);
            this.gunaLabel8.TabIndex = 19;
            this.gunaLabel8.Text = "Contact:";
            // 
            // gunaLabel9
            // 
            this.gunaLabel9.AutoSize = true;
            this.gunaLabel9.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.gunaLabel9.Font = new System.Drawing.Font("Sitka Heading", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel9.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.gunaLabel9.Location = new System.Drawing.Point(115, 501);
            this.gunaLabel9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.gunaLabel9.Name = "gunaLabel9";
            this.gunaLabel9.Size = new System.Drawing.Size(85, 28);
            this.gunaLabel9.TabIndex = 20;
            this.gunaLabel9.Text = "Address:";
            // 
            // SpecT
            // 
            this.SpecT.BackColor = System.Drawing.Color.Transparent;
            this.SpecT.BaseColor = System.Drawing.Color.Black;
            this.SpecT.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SpecT.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SpecT.FocusedBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SpecT.FocusedBorderColor = System.Drawing.Color.Black;
            this.SpecT.FocusedForeColor = System.Drawing.Color.White;
            this.SpecT.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.SpecT.ForeColor = System.Drawing.Color.White;
            this.SpecT.Location = new System.Drawing.Point(204, 410);
            this.SpecT.Margin = new System.Windows.Forms.Padding(2);
            this.SpecT.Name = "SpecT";
            this.SpecT.PasswordChar = '\0';
            this.SpecT.SelectedText = "";
            this.SpecT.Size = new System.Drawing.Size(199, 32);
            this.SpecT.TabIndex = 8;
            // 
            // gunaLabel7
            // 
            this.gunaLabel7.AutoSize = true;
            this.gunaLabel7.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.gunaLabel7.Font = new System.Drawing.Font("Sitka Heading", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel7.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.gunaLabel7.Location = new System.Drawing.Point(66, 414);
            this.gunaLabel7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.gunaLabel7.Name = "gunaLabel7";
            this.gunaLabel7.Size = new System.Drawing.Size(131, 28);
            this.gunaLabel7.TabIndex = 18;
            this.gunaLabel7.Text = "Specialization";
            // 
            // signupT_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 591);
            this.Controls.Add(this.gunaLabel9);
            this.Controls.Add(this.gunaLabel8);
            this.Controls.Add(this.gunaLabel7);
            this.Controls.Add(this.gunaLabel6);
            this.Controls.Add(this.gunaLabel5);
            this.Controls.Add(this.gunaLabel4);
            this.Controls.Add(this.gunaLabel3);
            this.Controls.Add(this.gunaLabel2);
            this.Controls.Add(this.gunaLabel1);
            this.Controls.Add(this.Button1);
            this.Controls.Add(this.AddT);
            this.Controls.Add(this.ContactT);
            this.Controls.Add(this.SpecT);
            this.Controls.Add(this.GenderT);
            this.Controls.Add(this.CNICT);
            this.Controls.Add(this.EmailT);
            this.Controls.Add(this.passT);
            this.Controls.Add(this.UnameT);
            this.Controls.Add(this.NameT);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "signupT_form";
            this.Text = "$";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private Guna.UI.WinForms.GunaTextBox NameT;
        private Guna.UI.WinForms.GunaTextBox UnameT;
        private Guna.UI.WinForms.GunaTextBox passT;
        private Guna.UI.WinForms.GunaTextBox EmailT;
        private Guna.UI.WinForms.GunaTextBox CNICT;
        private Guna.UI.WinForms.GunaTextBox GenderT;
        private Guna.UI.WinForms.GunaTextBox ContactT;
        private Guna.UI.WinForms.GunaTextBox AddT;
        private Guna.UI.WinForms.GunaButton Button1;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaLabel gunaLabel3;
        private Guna.UI.WinForms.GunaLabel gunaLabel4;
        private Guna.UI.WinForms.GunaLabel gunaLabel5;
        private Guna.UI.WinForms.GunaLabel gunaLabel6;
        private Guna.UI.WinForms.GunaLabel gunaLabel8;
        private Guna.UI.WinForms.GunaLabel gunaLabel9;
        private Guna.UI.WinForms.GunaTextBox SpecT;
        private Guna.UI.WinForms.GunaLabel gunaLabel7;
    }
}