﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace dbproject
{
    public partial class membercreatework : Form
    {
        public static membercreatework instance;
        public string userid;
        public int useri;
        public membercreatework()
        {
            InitializeComponent();
            instance = this;
            membergridview();
        }

        public void membergridview()
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            string query = "SELECT * FROM EXERCISE";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable d1 = new DataTable();
            da.Fill(d1);
            membergymdatagridview.DataSource = d1;
            conn.Close();
        }


        private void gunaButton2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True"); // Connection String
            conn.Open();
            SqlCommand cm;

            string name = textBox1.Text;
            string level = textBox2.Text;
            string description = textBox3.Text;
            string e1 = textBox4.Text;
            string e2 = textBox5.Text;
            string e3 = textBox6.Text;
            if (name != "" && level != "" && description != "" && e1 != "")
            {
                int i1 = Int32.Parse(e1);

                //insert into WORKOUT_PLAN values( userid,textbox1,textbox2,descriptiontextbox)
                string query = "INSERT INTO WORKOUT_PLAN (CREATED_BY, NAME1, LEVEL1, DESCRIPTION1) VALUES (" + useri + ", '" + name + "', " + Int32.Parse(level) + ", '" + description + "')";

                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();


                query = "SELECT MAX(WP_ID) AS Latest_WP_ID FROM Workout_PLAN";
                cm = new SqlCommand(query, conn);
                object o1 = cm.ExecuteScalar();

                int wp_id = Int32.Parse(o1.ToString());

                // insert into EXERCISE_CONTAIN values(textbox1, WP_ID)
                query = "INSERT INTO EXERCISE_CONTAIN (EXERCISE_ID, WP_ID) VALUES (" + i1 + ", " + wp_id + ")";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                if (e2 != "")
                {
                    i1 = Int32.Parse(e2);
                    query = "INSERT INTO EXERCISE_CONTAIN (EXERCISE_ID, WP_ID) VALUES (" + i1 + ", " + wp_id + ")";
                    cm = new SqlCommand(query, conn);
                    cm.ExecuteNonQuery();
                }

                if (e3 != "")
                {
                    i1 = Int32.Parse(e3);
                    query = "INSERT INTO EXERCISE_CONTAIN (EXERCISE_ID, WP_ID) VALUES (" + i1 + ", " + wp_id + ")";
                    cm = new SqlCommand(query, conn);
                    cm.ExecuteNonQuery();
                }


                query = "UPDATE MEMBER1 SET WP_ID = +'" + wp_id + "' WHERE MEMBER_ID = +'" + useri + "'";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("Updated!!");
                this.Hide();
            }
            else
                MessageBox.Show("Please fill all required boxes, (Only Exercise2 and Exercise3 are optional)");

        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
