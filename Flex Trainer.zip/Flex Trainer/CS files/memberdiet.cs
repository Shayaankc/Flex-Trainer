﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using DB_Project;

namespace dbproject
{
    public partial class memberdiet : Form
    {
        public static memberdiet instance;
        public string userid;
        public int useri;

        public member_main parentForm;
        public memberdiet()
        {
            InitializeComponent();
            instance = this;
            membergridview();
        }

     

        private void button2_Click(object sender, EventArgs e)
        {

        }
            
        public void membergridview()
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();

            string query1 = "SELECT DIET_PLAN.DIETPLAN_ID AS ID,DIET_PLAN.NAME1 AS NAME,DIET_PLAN.GOAL,DIET_PLAN.DESCRIPTION1 AS ABOUT FROM DIET_PLAN JOIN TRAINER ON TRAINER.TRAINER_ID=DIET_PLAN.CREATED_BY JOIN WORKS_AT ON TRAINER.TRAINER_ID = WORKS_AT.TRAINER_ID JOIN GYM ON GYM.GYM_ID = WORKS_AT.GYM_ID JOIN MEMBER1 ON MEMBER1.GYM_ID = GYM.GYM_ID WHERE MEMBER1.MEMBER_ID = +'" + useri + "'";


            SqlDataAdapter da1 = new SqlDataAdapter(query1, conn);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);

            string query2 = "SELECT DIET_PLAN.DIETPLAN_ID AS ID,DIET_PLAN.NAME1 AS NAME,DIET_PLAN.GOAL,DIET_PLAN.DESCRIPTION1 AS ABOUT FROM DIET_PLAN JOIN MEMBER1 ON MEMBER1.MEMBER_ID=DIET_PLAN.CREATED_BY WHERE MEMBER1.MEMBER_ID = +'" + useri + "'";

            SqlDataAdapter da2 = new SqlDataAdapter(query2, conn);
            DataTable dt2 = new DataTable();
            da2.Fill(dt2);

            DataTable mergedDataTable = dt1.Clone();
            mergedDataTable.Merge(dt1);
            mergedDataTable.Merge(dt2);

            membergymdatagridview.DataSource = mergedDataTable;

            conn.Close();
        }
        public void currlabel()
        {
            string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";

            SqlConnection conn = new SqlConnection(connectionString);

            conn.Open();

            string query = " SELECT DIET_PLAN.DIETPLAN_ID,DIET_PLAN.NAME1,DIET_PLAN.TYPE1 FROM DIET_PLAN JOIN MEMBER1 ON DIET_PLAN.DIETPLAN_ID = MEMBER1.DP_ID WHERE MEMBER1.MEMBER_ID = +'" + Int32.Parse(userid) + "' ";
            SqlCommand cm = new SqlCommand(query, conn);


            SqlDataReader reader = cm.ExecuteReader();

            if (reader.Read())
            {
                int dietPlanId = reader.GetInt32(reader.GetOrdinal("DIETPLAN_ID"));
                string dietPlanName = reader.GetString(reader.GetOrdinal("NAME1"));
                string dietPlanType = reader.GetString(reader.GetOrdinal("TYPE1"));

                label3.Text = $"Current Diet Plan: ID - {dietPlanId}, Name - {dietPlanName}, Type - {dietPlanType}";
            }
            else
            {
                label3.Text = "The User Does Not Have A Diet Plan!";
            }

            reader.Close();
            conn.Close();

        }
        private void membergymdatagridview_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int id = Convert.ToInt32(membergymdatagridview.Rows[e.RowIndex].Cells["ID"].Value);

            MessageBox.Show(id.ToString());
        
        
        
        }
        private void gunaButton1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(" Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            SqlCommand cm;


            string choice = textBox1.Text;
            if (choice != "")
            {
                int c = Int32.Parse(choice);


                string query = "UPDATE MEMBER1 SET DP_ID = +'" + c + "' WHERE MEMBER_ID = +'" + Int32.Parse(userid) + "'";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Updated!!");
            }

        }


        private void gunaButton2_Click(object sender, EventArgs e)
        {
            membercreatediet m1 = new membercreatediet();
            membercreatediet.instance.userid = userid;
            membercreatediet.instance.useri = useri;
            membercreatediet.instance.membergridview();
            m1.Show();
        }
    }
}
