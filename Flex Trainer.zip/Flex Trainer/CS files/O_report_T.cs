﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DB_Project
{
    public partial class O_report_T : Form
    {
        public static O_report_T instance;
        public int useri;
        public O_report_T()
        {
            InitializeComponent();
            instance = this;
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            string query = "SELECT USER1.FULLNAME AS TrainerName, AVG(RATING) AS AverageRating FROM TRAINER JOIN USER1 ON USER1.USERID=TRAINER.TRAINER_ID JOIN FEEDBACK ON TRAINER.TRAINER_ID = FEEDBACK.TRAINER_ID JOIN WORKS_AT ON WORKS_AT.TRAINER_ID=TRAINER.TRAINER_ID JOIN GYM ON GYM.GYM_ID=WORKS_AT.GYM_ID join OWNS ON OWNS.GYM_ID=GYM.GYM_ID JOIN OWNER1 ON OWNS.OWNER_ID=OWNER1.OWNER_ID WHERE OWNER1.OWNER_ID= +'" + useri + "' GROUP BY USER1.FULLNAME,TRAINER.TRAINER_ID";
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            string date = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            string query = "SELECT USER1.FULLNAME AS TrainerName,TRAINER.TRAINER_ID FROM TRAINER JOIN USER1 ON USER1.USERID = TRAINER.TRAINER_ID JOIN TRAINING_APPOINTMENT ON TRAINER.TRAINER_ID = TRAINING_APPOINTMENT.TRAINER_ID JOIN WORKS_AT ON WORKS_AT.TRAINER_ID = TRAINER.TRAINER_ID JOIN GYM ON GYM.GYM_ID = WORKS_AT.GYM_ID JOIN OWNS ON OWNS.GYM_ID=GYM.GYM_ID JOIN OWNER1 ON OWNER1.OWNER_ID=OWNS.OWNER_ID WHERE OWNER1.OWNER_ID= +'" + useri + "' AND TRAINING_APPOINTMENT.DATE1 IS NULL OR TRAINING_APPOINTMENT.DATE1 != "+date+ " group by  USER1.FULLNAME,TRAINER.TRAINER_ID";
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton3_Click(object sender, EventArgs e)
        {
            string query = "SELECT TRAINER.TRAINER_ID ,USER1.FULLNAME, TRAINER.SPECIALIZATION FROM TRAINER JOIN USER1 ON USER1.USERID=TRAINER.TRAINER_ID JOIN WORKS_AT ON WORKS_AT.TRAINER_ID=TRAINER.TRAINER_ID JOIN GYM ON GYM.GYM_ID=WORKS_AT.GYM_ID JOIN OWNS ON GYM.GYM_ID=OWNS.GYM_ID JOIN OWNER1 ON OWNER1.OWNER_ID=OWNS.OWNER_ID where OWNER1.OWNER_ID=+'" + useri + "' AND TRAINER.SPECIALIZATION = '" + comboBox1.Text + "'";
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton4_Click(object sender, EventArgs e)
        {
            string query = "SELECT USER1.FULLNAME AS OwnerName, GYM.NAME1 AS GymName, COUNT(TRAINER.TRAINER_ID) AS TrainerCount FROM OWNER1 JOIN USER1 ON USER1.USERID = OWNER1.OWNER_ID JOIN OWNS ON OWNER1.OWNER_ID = OWNS.OWNER_ID JOIN GYM ON OWNS.OWNER_ID = GYM.GYM_ID JOIN WORKS_AT ON GYM.GYM_ID = WORKS_AT.GYM_ID JOIN TRAINER ON WORKS_AT.TRAINER_ID = TRAINER.TRAINER_ID WHERE OWNER1.OWNER_ID = +'" + useri + "' GROUP BY USER1.FULLNAME, GYM.NAME1";
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void O_report_T_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
