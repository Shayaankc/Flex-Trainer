﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DB_Project
{
    public partial class NewTrain_O : Form
    {
        public static NewTrain_O instance;
        public string userid;
        public int useri;
        public NewTrain_O()
        {
            InitializeComponent();
            instance = this;
        }

        public void membergridview()
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            string query = "SELECT* FROM GYM_REQUEST";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable d1 = new DataTable();
            da.Fill(d1);
            membergymdatagridview.DataSource = d1;
            conn.Close();
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {

            string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionString);

            conn.Open();


            if (textBox1.Text != "")
            {
                string query = "SELECT GYM_ID FROM GYM_REQUEST WHERE REQ_ID = + '" + Int32.Parse(textBox1.Text) + "' ";
                SqlCommand cm = new SqlCommand(query, conn);
                object o1 = cm.ExecuteScalar();
                int gid = Int32.Parse(o1.ToString());

                query = "SELECT TRAINER_ID FROM GYM_REQUEST WHERE REQ_ID = + '" + Int32.Parse(textBox1.Text) + "' ";
                cm = new SqlCommand(query, conn);
                o1 = cm.ExecuteScalar();
                int tid = Int32.Parse(o1.ToString());

                query = "INSERT INTO WORKS_AT VALUES('" + tid + "', '" + gid + "')";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                gunaButton2_Click(sender, e);

                MessageBox.Show("Updated!!");
            }
            conn.Close();



        }


        private void gunaButton2_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionString);

            conn.Open();


            if (textBox1.Text != "")
            {
                string query = "DELETE FROM GYM_REQUEST WHERE REQ_ID = '" + Int32.Parse(textBox1.Text) + "'";
                SqlCommand cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                MessageBox.Show("SUCCESSFULLY REMOVED FROM LIST!!");
            }
            conn.Close();
        }
    }
}
