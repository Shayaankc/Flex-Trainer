﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace DB_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            timer1.Start();
           
        }

        private void Starting_label_Click(object sender, EventArgs e)
        {

        }

        private void Form1_load(object sender, EventArgs e)
        {
           
        

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (gunaProgressBar1.Value < 200)
                gunaProgressBar1.Increment(1);
            else
            {
                this.Hide();
                timer1.Stop();

                loging_form LF = new loging_form();

                LF.Show();
        

            }



        }



        private void gunaProgressBar1_Click(object sender, EventArgs e)
        {

        }

       
    }
}
