﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlClient;


namespace DB_Project
{
    public partial class T_report : Form
    {
        public T_report()
        {
            InitializeComponent();
        }

        private void T_report_Load(object sender, EventArgs e)
        {

        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            string query = "SELECT DIET_PLAN.NAME1, MEAL.NAME1 FROM DIET_PLAN JOIN MEAL_CONTAIN ON DIET_PLAN.DIETPLAN_ID = MEAL_CONTAIN.DIETPLAN_ID JOIN MEAL ON MEAL_CONTAIN.MEAL_ID = MEAL.MEAL_ID WHERE MEAL.TIME1 = '"+comboBox1.Text+"' AND MEAL.CAL < "+textBox1.Text+" GROUP BY DIET_PLAN.NAME1, MEAL.NAME1";
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            string query = "SELECT DIET_PLAN.NAME1, SUM(MEAL.CARBS) AS Total_Carbs FROM DIET_PLAN JOIN MEAL_CONTAIN ON DIET_PLAN.DIETPLAN_ID = MEAL_CONTAIN.DIETPLAN_ID JOIN MEAL ON MEAL_CONTAIN.MEAL_ID = MEAL.MEAL_ID GROUP BY DIET_PLAN.NAME1 HAVING SUM(MEAL.CARBS) < "+textBox2.Text;
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton3_Click(object sender, EventArgs e)
        {
            string query = "SELECT WORKOUT_PLAN.NAME1, WORKOUT_PLAN.DESCRIPTION1 FROM WORKOUT_PLAN JOIN EXERCISE_CONTAIN ON WORKOUT_PLAN.WP_ID = EXERCISE_CONTAIN.WP_ID JOIN EXERCISE ON EXERCISE_CONTAIN.EXERCISE_ID=EXERCISE.EXERCISE_ID WHERE EXERCISE.MACHINE_ID IS NULL GROUP BY WORKOUT_PLAN.NAME1, WORKOUT_PLAN.DESCRIPTION1";
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton4_Click(object sender, EventArgs e)
        {
            //peanut
            string query = "SELECT DIET_PLAN.* FROM DIET_PLAN join MEAL_CONTAIN on MEAL_CONTAIN.DIETPLAN_ID= DIET_PLAN.DIETPLAN_ID join MEAL on MEAL_CONTAIN.MEAL_ID=MEAL.MEAL_ID where MEAL.ALERGEN !='nuts'";
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }
    }
}
