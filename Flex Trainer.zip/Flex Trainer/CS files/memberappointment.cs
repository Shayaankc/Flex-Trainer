﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace dbproject
{
    public partial class memberappointment : Form
    {
        public static memberappointment instance;
        public string userid;
        public int useri;
        public memberappointment()
        {
            InitializeComponent();
            instance = this;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }



        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }
        public void membergridview()
        {
            SqlConnection conn = new SqlConnection(" Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            string query = "SELECT TRAINER.TRAINER_ID AS ID,TRAINER.CONTACT,TRAINER.GENDER,TRAINER.SPECIALIZATION FROM TRAINER  JOIN WORKS_AT ON TRAINER.TRAINER_ID = WORKS_AT.TRAINER_ID JOIN GYM ON GYM.GYM_ID = WORKS_AT.GYM_ID JOIN MEMBER1 ON MEMBER1.GYM_ID = GYM.GYM_ID WHERE MEMBER1.MEMBER_ID = +'" + useri + "'";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable d1 = new DataTable();
            da.Fill(d1);
            membergymdatagridview.DataSource = d1;
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }
        public void currlabel()
        {
            string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string query = "SELECT TA_ID, DATE1, TIME1, TRAINER_ID FROM TRAINING_APPOINTMENT WHERE MEMBER_ID = + '" + useri + "'";

                SqlCommand cm = new SqlCommand(query, conn);
                SqlDataReader reader = cm.ExecuteReader();

                StringBuilder appstr = new StringBuilder();

                while (reader.Read())
                {
                    int appointmentId = reader.GetInt32(reader.GetOrdinal("TA_ID"));
                    string date = reader.GetString(reader.GetOrdinal("DATE1"));
                    string time = reader.GetString(reader.GetOrdinal("TIME1"));
                    int trainerId = reader.GetInt32(reader.GetOrdinal("TRAINER_ID"));


                    appstr.AppendLine($"Appointment ID: {appointmentId}, Date: {date}, Time: {time}, Trainer ID: {trainerId}");
                }

                reader.Close();
                conn.Close();

                if (appstr.Length > 0)
                {
                    label3.Text = appstr.ToString();
                }
                else
                {
                    label3.Text = "No Up Coming Appointments!";
                }
            }
        }
        
      
        private void gunaButton1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True"); // Connection String
            conn.Open();
            SqlCommand cm;

            string date = dateTimePicker1.Value.ToString("dd-MM-yyyy");
            string time = dateTimePicker2.Value.ToString("HH:mm:ss");
            string tid = textBox1.Text;
            if (tid != "")
            {
                int c = Int32.Parse(tid);

                string query = "INSERT INTO TRAINING_APPOINTMENT VALUES (" + useri + ", " + tid + ", '" + date + "', '" + time + "')";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Updated!!");
            }


        }
    }

}

