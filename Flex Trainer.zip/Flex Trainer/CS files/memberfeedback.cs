﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace dbproject
{
    public partial class memberfeedback : Form
    {
        public static memberfeedback instance;
        public string userid;
        public int useri;
        public memberfeedback()
        {
            InitializeComponent();
            instance = this;
        }
        private void memberfeedback_Load(object sender, EventArgs e)
        {

        }

        public void membergridview()
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            string query = "SELECT TRAINER.TRAINER_ID AS ID,TRAINER.CONTACT,TRAINER.GENDER,TRAINER.SPECIALIZATION FROM TRAINER  JOIN WORKS_AT ON TRAINER.TRAINER_ID = WORKS_AT.TRAINER_ID JOIN GYM ON GYM.GYM_ID = WORKS_AT.GYM_ID JOIN MEMBER1 ON MEMBER1.GYM_ID = GYM.GYM_ID WHERE MEMBER1.MEMBER_ID = +'" + useri + "'";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable d1 = new DataTable();
            da.Fill(d1);
            membergymdatagridview.DataSource = d1;
            conn.Close();
        }



        private void button1_Click_1(object sender, EventArgs e)
        {
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {

            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True"); // Connection String
            conn.Open();
            SqlCommand cm;


            string tid = textBox1.Text;
            if (tid != "")
            {

                int c = Int32.Parse(tid);

                string desc = textBox2.Text;

                string ra = textBox3.Text;
                int rating = Int32.Parse(ra);

                string query = "INSERT INTO FEEDBACK VALUES ('" + desc + "', " + rating + ", '" + useri + "', " + c + ")";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Updated!!");

            }

        }
    }
}
