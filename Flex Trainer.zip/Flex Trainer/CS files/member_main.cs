﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using dbproject;

namespace DB_Project
{
    public partial class member_main : Form
    {
   
        Workout_M Workout_M;
        memberappointment book_Trainer_M;
        memberfeedback memberfeedback;
        memberdiet memberdiet;
        membergym membergym;

        public static member_main instance;
        public string userid;

        System.Media.SoundPlayer player = new System.Media.SoundPlayer();

        public member_main()
        {
            InitializeComponent();
            instance = this;
            this.Size = new System.Drawing.Size(800, 590);
            player.SoundLocation = "puneet.wav";
           // player.Play();

        }

        public void loadform(object Form)
        { 
            if(this.main_panel.Controls.Count > 0) 
            {
                Form previousForm = this.main_panel.Controls[0] as Form;
                previousForm.Close();
            }
            Form f = Form as Form;
            f.TopLevel = false;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.main_panel.Controls.Add(f);
            this.main_panel.Tag = f;
            f.Show();
        }

        private void member_main_Load(object sender, EventArgs e)
        {

        }

        bool sidbarexpand = true;
        private void transitiontimer_Tick(object sender, EventArgs e)
        {
            if (sidbarexpand)
            {
                side_bar.Width -= 7;

                if (side_bar.Width <= 70)
                {
                    sidbarexpand = false;
                    transitiontimer.Stop();

                    WPP.Width = side_bar.Width;
                    DPP.Width = side_bar.Width;
                    BTP.Width = side_bar.Width;
                    FBP.Width = side_bar.Width;
                }
            }
            else 
            {
                side_bar.Width += 7;

                if (side_bar.Width >= 200)
                {
                    sidbarexpand = true;
                    transitiontimer.Stop();

                    WPP.Width=side_bar.Width;
                    DPP.Width = side_bar.Width;
                    BTP.Width = side_bar.Width;
                    FBP.Width = side_bar.Width;
                }
            }
        }

        private void TOP_BUTTON_Click(object sender, EventArgs e)
        {
            transitiontimer.Start();

        }

        private void FBB_Click(object sender, EventArgs e)
        {
            memberfeedback m1 = new memberfeedback();
            memberfeedback.instance.userid = userid;
            memberfeedback.instance.useri = Int32.Parse(userid);
            memberfeedback.instance.membergridview();
            loadform(m1);
        }

        private void WKB_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            SqlCommand cm;

            string query = "Select GYM_ID from MEMBER1 where MEMBER_ID =  + '" + Int32.Parse(userid) + "' ";
            cm = new SqlCommand(query, conn);

            object o1 = cm.ExecuteScalar();

            if (o1.ToString() == "")
            {
                MessageBox.Show("PLEASE JOIN A GYM FIRST!!");
               
                membergym m1 = new membergym();
                membergym.instance.userid = userid;
                loadform(m1);
            }
            else
            {

                Workout_M m1 = new Workout_M();
                Workout_M.instance.userid = userid;
                Workout_M.instance.useri = Int32.Parse(userid);
                Workout_M.instance.membergridview();
                Workout_M.instance.workoutlabel();
                loadform(m1);
            }
        }

        private void BTB_Click(object sender, EventArgs e)
        {
            memberappointment m1 = new memberappointment();
            memberappointment.instance.userid = userid;
            memberappointment.instance.useri = Int32.Parse(userid);
            memberappointment.instance.membergridview();
            memberappointment.instance.currlabel();
            loadform(m1);
        }

        private void DPB_Click(object sender, EventArgs e)
        {
            memberdiet m1 = new memberdiet();
            memberdiet.instance.userid = userid;
            memberdiet.instance.useri = Int32.Parse(userid);
            memberdiet.instance.membergridview();
            memberdiet.instance.currlabel();
            loadform(m1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            membergym m1 = new membergym();
            membergym.instance.userid = userid;
            membergym.instance.currlabel();
            loadform(m1);
        }

    }
}
