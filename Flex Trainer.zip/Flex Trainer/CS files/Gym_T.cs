﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DB_Project
{
    public partial class Gym_T : Form
    {
        public static Gym_T instance;
        public string userid;
        public int useri;
        public Gym_T()
        {
            InitializeComponent();
            instance = this;
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {


            string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionString);

            conn.Open();


            if (textBox1.Text != "")
            {
                string query = " SELECT OWNER1.OWNER_ID FROM OWNER1 JOIN OWNS ON OWNS.OWNER_ID = OWNER1.OWNER_ID JOIN GYM ON OWNS.GYM_ID = GYM.GYM_ID WHERE GYM.GYM_ID = + '" + Int32.Parse(textBox1.Text) + "' ";
                SqlCommand cm = new SqlCommand(query, conn);
                object o1=cm.ExecuteScalar();
                int oid = Int32.Parse(o1.ToString());

                query = "INSERT INTO GYM_REQUEST VALUES('" + useri + "', '" + Int32.Parse(textBox1.Text) + "', '" + oid + "')";
                cm = new SqlCommand(query, conn);

                cm.ExecuteNonQuery();

                MessageBox.Show("Updated!!");
            }
            conn.Close();

        }
        public void currlabel()
        {
            string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";

            SqlConnection conn = new SqlConnection(connectionString);

            conn.Open();

            string query = "select count(*) from WORKS_AT where TRAINER_ID= + '" + useri + "' ";

            SqlCommand cm = new SqlCommand(query, conn);
            int count = (int)cm.ExecuteScalar();

            conn.Close();

            label3.Text = "You Are Currently Working at " + count.ToString() + " gyms!!";

        }


        public void membergridview()
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            string query = "SELECT GYM.GYM_ID AS ID, GYM.NAME1 AS NAME, GYM.LOCATION1 AS LOC FROM GYM  WHERE GYM.GYM_ID NOT IN ( SELECT WORKS_AT.GYM_ID FROM WORKS_AT WHERE WORKS_AT.TRAINER_ID =+ '" + useri + "' )";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable d1 = new DataTable();
            da.Fill(d1);
            membergymdatagridview.DataSource = d1;
            conn.Close();
        }
    }
}
