﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DB_Project
{
    public partial class O_report_M : Form
    {
        public static O_report_M instance;
        public int useri;
        public O_report_M()
        {
            InitializeComponent();
            instance = this;
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            string query = "SELECT USER1.USERNAME, USER1.FULLNAME, MEMBER1.CONTACT, MEMBER1.JOINING_DATE FROM USER1 JOIN MEMBER1 ON USER1.USERID=MEMBER1.MEMBER_ID JOIN OWNS ON MEMBER1.GYM_ID=OWNS.GYM_ID JOIN OWNER1 ON OWNER1.OWNER_ID=OWNS.OWNER_ID WHERE OWNER1.OWNER_ID= +'"+useri+"' AND JOINING_DATE >= DATEADD(month, -3, GETDATE())";
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            string query = "Select USER1.FULLNAME,MEMBER1.PACKAGE FROM USER1 JOIN MEMBER1 ON USER1.USERID=MEMBER1.MEMBER_ID JOIN GYM ON GYM.GYM_ID=MEMBER1.GYM_ID JOIN OWNS ON GYM.GYM_ID=OWNS.GYM_ID JOIN OWNER1 ON OWNER1.OWNER_ID=OWNS.OWNER_ID where OWNER1.OWNER_ID=+'"+useri+ "' AND MEMBER1.PACKAGE = '" +comboBox1.Text+ "' group by USER1.FULLNAME,MEMBER1.PACKAGE";
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton3_Click(object sender, EventArgs e)
        {
            string date = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            string query = "SELECT USER1.USERNAME, USER1.FULLNAME, TRAINING_APPOINTMENT.DATE1, TRAINING_APPOINTMENT.TIME1 FROM MEMBER1 JOIN USER1 ON USER1.USERID=MEMBER1.MEMBER_ID JOIN TRAINING_APPOINTMENT ON MEMBER1.MEMBER_ID=TRAINING_APPOINTMENT.MEMBER_ID JOIN GYM ON GYM.GYM_ID=MEMBER1.GYM_ID JOIN OWNS ON GYM.GYM_ID=OWNS.GYM_ID JOIN OWNER1 ON OWNER1.OWNER_ID=OWNS.OWNER_ID where OWNER1.OWNER_ID=+'"+useri+"' AND TRAINING_APPOINTMENT.DATE1= "+date;
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton4_Click(object sender, EventArgs e)
        {
            string query = "SELECT COUNT(*) AS GoalCount, DIET_PLAN.GOAL FROM MEMBER1 JOIN DIET_PLAN ON MEMBER1.DP_ID = DIET_PLAN.DIETPLAN_ID JOIN OWNS ON MEMBER1.GYM_ID=OWNS.GYM_ID JOIN OWNER1 ON OWNER1.OWNER_ID=OWNS.OWNER_ID WHERE OWNER1.OWNER_ID= +'"+useri+"' GROUP BY DIET_PLAN.GOAL ORDER BY GoalCount DESC";
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }
    }
    
}
