﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DB_Project
{
    public partial class POG_A : Form
    {
        public static POG_A instance;
        public string userid;
        public int useri;
        public POG_A()
        {
            InitializeComponent();
            instance = this;
        }

        private void POG_A_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            string query = "SELECT GYM.GYM_ID AS ID, GYM.NAME1 AS Gym_Name, COUNT(*) AS Total_Members FROM GYM INNER JOIN MEMBER1 ON GYM.GYM_ID = MEMBER1.GYM_ID WHERE MEMBER1.JOINING_DATE >= DATEADD(month, -6, GETDATE()) GROUP BY GYM.NAME1,GYM.GYM_ID ORDER BY total_members DESC";

            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            string query = "SELECT USER1.USERNAME, USER1.FULLNAME, MEMBER1.CONTACT FROM USER1 JOIN MEMBER1 ON USER1.USERID=MEMBER1.MEMBER_ID JOIN WORKS_AT ON MEMBER1.GYM_ID = WORKS_AT.GYM_ID JOIN TRAINER ON WORKS_AT.TRAINER_ID = TRAINER.TRAINER_ID WHERE MEMBER1.GYM_ID = + "+Int32.Parse(textBox1.Text)+" AND TRAINER.TRAINER_ID = "+Int32.Parse(textBox2.Text);
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton3_Click(object sender, EventArgs e)
        {
            string query = "SELECT USER1.USERNAME, USER1.FULLNAME, MEMBER1.CONTACT, DIET_PLAN.NAME1 FROM  USER1 JOIN MEMBER1 ON USER1.USERID=MEMBER1.MEMBER_ID JOIN DIET_PLAN ON MEMBER1.DP_ID = DIET_PLAN.DIETPLAN_ID WHERE MEMBER1.GYM_ID = + " + Int32.Parse(textBox3.Text) + " AND DIET_PLAN.DIETPLAN_ID  = " + Int32.Parse(textBox4.Text);
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton4_Click(object sender, EventArgs e)
        {
            string query = "SELECT USER1.USERNAME, USER1.FULLNAME, MEMBER1.CONTACT, GYM.NAME1 AS Gym_Name FROM USER1 JOIN MEMBER1 ON USER1.USERID=MEMBER1.MEMBER_ID JOIN DIET_PLAN ON MEMBER1.DP_ID = DIET_PLAN.DIETPLAN_ID JOIN GYM ON GYM.GYM_ID = MEMBER1.GYM_ID JOIN WORKS_AT ON WORKS_AT.GYM_ID = GYM.GYM_ID JOIN TRAINER ON TRAINER.TRAINER_ID = WORKS_AT.TRAINER_ID WHERE TRAINER.TRAINER_ID= + " + Int32.Parse(textBox5.Text) + " AND DIET_PLAN.DIETPLAN_ID = " + Int32.Parse(textBox6.Text);
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton5_Click(object sender, EventArgs e)
        {
            string query = "SELECT COUNT(*) AS Machine_Usage_Count FROM MACHINE JOIN EXERCISE ON MACHINE.MACHINE_ID = EXERCISE.MACHINE_ID JOIN EXERCISE_CONTAIN ON EXERCISE_CONTAIN.EXERCISE_ID = EXERCISE.EXERCISE_ID JOIN WORKOUT_PLAN ON EXERCISE_CONTAIN.WP_ID=WORKOUT_PLAN.WP_ID JOIN MEMBER1 ON MEMBER1.WP_ID=WORKOUT_PLAN.WP_ID JOIN GYM ON GYM.GYM_ID=MEMBER1.GYM_ID WHERE MACHINE.MACHINE_ID= + " + Int32.Parse(textBox7.Text) + " AND GYM.GYM_ID= + " + Int32.Parse(textBox8.Text) + " AND EXERCISE.DAY1="+comboBox1.Text;
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton6_Click(object sender, EventArgs e)
        {
            string query = "SELECT GYM.NAME1 AS GymName, COUNT(DISTINCT TRAINER.TRAINER_ID) AS TrainerCount FROM GYM JOIN WORKS_AT ON GYM.GYM_ID = WORKS_AT.GYM_ID JOIN TRAINER ON WORKS_AT.TRAINER_ID = TRAINER.TRAINER_ID GROUP BY GYM.NAME1";
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton7_Click(object sender, EventArgs e)
        {
            string query = "SELECT GYM.NAME1 AS GymName, COUNT(*) AS MemberCount FROM GYM JOIN MEMBER1 ON GYM.GYM_ID = MEMBER1.GYM_ID GROUP BY GYM.NAME1";
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }

        private void gunaButton8_Click(object sender, EventArgs e)
        {
            string query = "SELECT OWNER1.OWNER_ID, USER1.FULLNAME AS OwnerName, COUNT( OWNS.GYM_ID) AS GymCount FROM OWNER1 JOIN USER1 ON USER1.USERID=OWNER1.OWNER_ID JOIN OWNS ON OWNS.OWNER_ID=OWNER1.OWNER_ID JOIN GYM ON GYM.GYM_ID=OWNS.OWNER_ID GROUP BY OWNER1.OWNER_ID,USER1.FULLNAME";
            Report r1 = new Report();
            Report.instance.query = query;
            Report.instance.membergridview();
            r1.Show();
        }
    }
}
