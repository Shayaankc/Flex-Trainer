﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DB_Project
{
    public partial class Feedback_T : Form
    {
        public static Feedback_T instance;
        public string userid;
        public int useri;
        public Feedback_T()
        {
            InitializeComponent();
            instance = this;
        }

        private void Feedback_T_Load(object sender, EventArgs e)
        {

        }
        public void currlabel()
        {
            string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";

            SqlConnection conn = new SqlConnection(connectionString);

            conn.Open();

            string query = "SELECT AVG(FEEDBACK.RATING) AS AVERAGE_RATING, TRAINER.TRAINER_ID FROM TRAINER LEFT JOIN FEEDBACK ON TRAINER.TRAINER_ID = FEEDBACK.TRAINER_ID WHERE TRAINER.TRAINER_ID = + '" + useri + "' GROUP BY TRAINER.TRAINER_ID";

            SqlCommand cm = new SqlCommand(query, conn);
            int count = (int)cm.ExecuteScalar();

            conn.Close();

            label3.Text = "YOUR RATING ACROSS ALL THE GYMS U CURRENTLY WORK AT IS: " + count;
        }


        public void membergridview()
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            string query = "SELECT RATING,DESCRIPTION1 AS DESCRIPTION,GYM.GYM_ID AS GYMID FROM FEEDBACK JOIN MEMBER1 ON MEMBER1.MEMBER_ID=FEEDBACK.MEMBER_ID JOIN GYM ON MEMBER1.GYM_ID=GYM.GYM_ID WHERE FEEDBACK.TRAINER_ID=+ '" + useri + "'";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable d1 = new DataTable();
            da.Fill(d1);
            membergymdatagridview.DataSource = d1;
            conn.Close();
        }
    }
}
