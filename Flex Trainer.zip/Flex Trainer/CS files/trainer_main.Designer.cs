﻿namespace DB_Project
{
    partial class trainer_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(trainer_main));
            this.panel1 = new System.Windows.Forms.Panel();
            this.TOP_BUTTON = new System.Windows.Forms.PictureBox();
            this.side_bar = new System.Windows.Forms.FlowLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.DPP = new System.Windows.Forms.Panel();
            this.DPB = new System.Windows.Forms.Button();
            this.FBP = new System.Windows.Forms.Panel();
            this.FBB = new System.Windows.Forms.Button();
            this.BTP = new System.Windows.Forms.Panel();
            this.BTB = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.transitiontimer = new System.Windows.Forms.Timer(this.components);
            this.main_panel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Flex = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.TOP_BUTTON)).BeginInit();
            this.side_bar.SuspendLayout();
            this.panel3.SuspendLayout();
            this.DPP.SuspendLayout();
            this.FBP.SuspendLayout();
            this.BTP.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gold;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(222, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(614, 35);
            this.panel1.TabIndex = 0;
            // 
            // TOP_BUTTON
            // 
            this.TOP_BUTTON.BackColor = System.Drawing.Color.Gold;
            this.TOP_BUTTON.Image = ((System.Drawing.Image)(resources.GetObject("TOP_BUTTON.Image")));
            this.TOP_BUTTON.Location = new System.Drawing.Point(6, 2);
            this.TOP_BUTTON.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.TOP_BUTTON.Name = "TOP_BUTTON";
            this.TOP_BUTTON.Size = new System.Drawing.Size(32, 34);
            this.TOP_BUTTON.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.TOP_BUTTON.TabIndex = 1;
            this.TOP_BUTTON.TabStop = false;
            this.TOP_BUTTON.Click += new System.EventHandler(this.TOP_BUTTON_Click);
            // 
            // side_bar
            // 
            this.side_bar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(24)))), ((int)(((byte)(29)))));
            this.side_bar.Controls.Add(this.panel3);
            this.side_bar.Controls.Add(this.DPP);
            this.side_bar.Controls.Add(this.FBP);
            this.side_bar.Controls.Add(this.BTP);
            this.side_bar.Controls.Add(this.panel4);
            this.side_bar.Controls.Add(this.panel5);
            this.side_bar.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.side_bar.Location = new System.Drawing.Point(0, 35);
            this.side_bar.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.side_bar.Name = "side_bar";
            this.side_bar.Size = new System.Drawing.Size(222, 542);
            this.side_bar.TabIndex = 1;
            this.side_bar.Paint += new System.Windows.Forms.PaintEventHandler(this.side_bar_Paint);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button1);
            this.panel3.Location = new System.Drawing.Point(1, 2);
            this.panel3.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(222, 85);
            this.panel3.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Font = new System.Drawing.Font("Sitka Heading", 10.125F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(-17, -12);
            this.button1.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(258, 112);
            this.button1.TabIndex = 2;
            this.button1.Text = "Appointments";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // DPP
            // 
            this.DPP.Controls.Add(this.DPB);
            this.DPP.Location = new System.Drawing.Point(1, 91);
            this.DPP.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.DPP.Name = "DPP";
            this.DPP.Size = new System.Drawing.Size(222, 85);
            this.DPP.TabIndex = 4;
            // 
            // DPB
            // 
            this.DPB.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DPB.Font = new System.Drawing.Font("Sitka Heading", 10.125F, System.Drawing.FontStyle.Bold);
            this.DPB.ForeColor = System.Drawing.Color.White;
            this.DPB.Image = ((System.Drawing.Image)(resources.GetObject("DPB.Image")));
            this.DPB.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DPB.Location = new System.Drawing.Point(-17, -12);
            this.DPB.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.DPB.Name = "DPB";
            this.DPB.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.DPB.Size = new System.Drawing.Size(258, 106);
            this.DPB.TabIndex = 2;
            this.DPB.Text = "Workout Plan";
            this.DPB.UseVisualStyleBackColor = false;
            this.DPB.Click += new System.EventHandler(this.DPB_Click);
            // 
            // FBP
            // 
            this.FBP.Controls.Add(this.FBB);
            this.FBP.Location = new System.Drawing.Point(1, 180);
            this.FBP.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.FBP.Name = "FBP";
            this.FBP.Size = new System.Drawing.Size(222, 85);
            this.FBP.TabIndex = 4;
            // 
            // FBB
            // 
            this.FBB.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FBB.Font = new System.Drawing.Font("Sitka Heading", 10.125F, System.Drawing.FontStyle.Bold);
            this.FBB.ForeColor = System.Drawing.Color.White;
            this.FBB.Image = ((System.Drawing.Image)(resources.GetObject("FBB.Image")));
            this.FBB.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FBB.Location = new System.Drawing.Point(-17, -12);
            this.FBB.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.FBB.Name = "FBB";
            this.FBB.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.FBB.Size = new System.Drawing.Size(258, 112);
            this.FBB.TabIndex = 2;
            this.FBB.Text = "Diet Plan";
            this.FBB.UseVisualStyleBackColor = false;
            this.FBB.Click += new System.EventHandler(this.FBB_Click);
            // 
            // BTP
            // 
            this.BTP.Controls.Add(this.BTB);
            this.BTP.Location = new System.Drawing.Point(1, 269);
            this.BTP.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.BTP.Name = "BTP";
            this.BTP.Size = new System.Drawing.Size(222, 85);
            this.BTP.TabIndex = 5;
            // 
            // BTB
            // 
            this.BTB.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BTB.Font = new System.Drawing.Font("Sitka Heading", 10.125F, System.Drawing.FontStyle.Bold);
            this.BTB.ForeColor = System.Drawing.Color.White;
            this.BTB.Image = ((System.Drawing.Image)(resources.GetObject("BTB.Image")));
            this.BTB.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BTB.Location = new System.Drawing.Point(-17, -12);
            this.BTB.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.BTB.Name = "BTB";
            this.BTB.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.BTB.Size = new System.Drawing.Size(258, 112);
            this.BTB.TabIndex = 2;
            this.BTB.Text = "Feedback";
            this.BTB.UseVisualStyleBackColor = false;
            this.BTB.Click += new System.EventHandler(this.BTB_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button2);
            this.panel4.Location = new System.Drawing.Point(1, 358);
            this.panel4.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(222, 85);
            this.panel4.TabIndex = 6;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Font = new System.Drawing.Font("Sitka Heading", 10.125F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(-17, -12);
            this.button2.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(258, 112);
            this.button2.TabIndex = 2;
            this.button2.Text = "Join Gym";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // transitiontimer
            // 
            this.transitiontimer.Interval = 10;
            this.transitiontimer.Tick += new System.EventHandler(this.transitiontimer_Tick);
            // 
            // main_panel
            // 
            this.main_panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.main_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.main_panel.Location = new System.Drawing.Point(222, 0);
            this.main_panel.Margin = new System.Windows.Forms.Padding(2);
            this.main_panel.Name = "main_panel";
            this.main_panel.Size = new System.Drawing.Size(614, 580);
            this.main_panel.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.TOP_BUTTON);
            this.panel2.Controls.Add(this.Flex);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(222, 580);
            this.panel2.TabIndex = 5;
            // 
            // Flex
            // 
            this.Flex.AutoSize = true;
            this.Flex.BackColor = System.Drawing.Color.Gold;
            this.Flex.Font = new System.Drawing.Font("Sitka Heading", 19.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Flex.Location = new System.Drawing.Point(-32, -3);
            this.Flex.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Flex.Name = "Flex";
            this.Flex.Size = new System.Drawing.Size(258, 38);
            this.Flex.TabIndex = 2;
            this.Flex.Text = "           FLEX TRAINER";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.button3);
            this.panel5.Location = new System.Drawing.Point(1, 447);
            this.panel5.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(222, 85);
            this.panel5.TabIndex = 7;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button3.Font = new System.Drawing.Font("Sitka Heading", 10.125F, System.Drawing.FontStyle.Bold);
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(-17, -12);
            this.button3.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.button3.Name = "button3";
            this.button3.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.button3.Size = new System.Drawing.Size(258, 112);
            this.button3.TabIndex = 2;
            this.button3.Text = "Reports";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // trainer_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(836, 580);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.side_bar);
            this.Controls.Add(this.main_panel);
            this.Controls.Add(this.panel2);
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.Name = "trainer_main";
            this.Text = "Trainer_main";
            this.Load += new System.EventHandler(this.member_main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TOP_BUTTON)).EndInit();
            this.side_bar.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.DPP.ResumeLayout(false);
            this.FBP.ResumeLayout(false);
            this.BTP.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox TOP_BUTTON;
        private System.Windows.Forms.FlowLayoutPanel side_bar;
        private System.Windows.Forms.Panel DPP;
        private System.Windows.Forms.Button DPB;
        private System.Windows.Forms.Panel BTP;
        private System.Windows.Forms.Button BTB;
        private System.Windows.Forms.Panel FBP;
        private System.Windows.Forms.Button FBB;
        private System.Windows.Forms.Timer transitiontimer;
        private System.Windows.Forms.Panel main_panel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label Flex;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button3;
    }
}