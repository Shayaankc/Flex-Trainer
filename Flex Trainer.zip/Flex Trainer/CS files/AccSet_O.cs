﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DB_Project
{
    public partial class AccSet_O : Form
    {
        public static AccSet_O instance;
        public string userid;
        public int useri;
        public AccSet_O()
        {
            InitializeComponent();
            instance = this;
        }


        public void membergridview()
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            string query = "SELECT MEMBER1.MEMBER_ID AS MEMBERID,GYM.GYM_ID AS GYMID,MEMBER1.PACKAGE,MEMBER1.ADDRESS1 AS ADDRESS,MEMBER1.JOINING_DATE,MEMBER1.AGE,MEMBER1.GENDER FROM MEMBER1 JOIN GYM ON MEMBER1.GYM_ID=GYM.GYM_ID JOIN OWNS ON OWNS.GYM_ID=GYM.GYM_ID JOIN OWNER1 ON OWNS.OWNER_ID=OWNER1.OWNER_ID WHERE OWNER1.OWNER_ID = + '" + useri + "'";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable d1 = new DataTable();
            da.Fill(d1);
            membergymdatagridview.DataSource = d1;
            conn.Close();
        }
        public void membergridview2()
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            string query = "SELECT TRAINER.TRAINER_ID AS TRAINERID,GYM.GYM_ID AS GYMID, TRAINER.SPECIALIZATION, TRAINER.CONTACT,TRAINER.ADDRESS1 AS ADDRESS,TRAINER.GENDER FROM TRAINER JOIN WORKS_AT ON TRAINER.TRAINER_ID=WORKS_AT.TRAINER_ID JOIN GYM ON GYM.GYM_ID=WORKS_AT.GYM_ID JOIN OWNS ON OWNS.GYM_ID=GYM.GYM_ID JOIN OWNER1 ON OWNS.OWNER_ID=OWNER1.OWNER_ID WHERE OWNER1.OWNER_ID = + '" + useri + "'";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable d1 = new DataTable();
            da.Fill(d1);
            dataGridView1.DataSource = d1;
            conn.Close();
        }

  
        private void gunaButton2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString);

                conn.Open();

                string query = " DELETE FROM FEEDBACK WHERE TRAINER_ID = + '" + Int32.Parse(textBox2.Text) + "' ";
                SqlCommand cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " DELETE FROM WORKS_AT WHERE TRAINER_ID = + '" + Int32.Parse(textBox2.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " DELETE FROM GYM_REQUEST WHERE TRAINER_ID = + '" + Int32.Parse(textBox2.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " DELETE FROM TRAINING_APPOINTMENT WHERE TRAINER_ID = + '" + Int32.Parse(textBox2.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " SELECT DIETPLAN_ID FROM DIET_PLAN WHERE CREATED_BY = + '" + Int32.Parse(textBox2.Text) + "' ";
                cm = new SqlCommand(query, conn);
                object o1 = cm.ExecuteScalar();

                if (o1.ToString() != "")
                {
                    query = " DELETE FROM MEAL_CONTAIN WHERE DIETPLAN_ID = + '" + Int32.Parse(o1.ToString()) + "' ";
                    cm = new SqlCommand(query, conn);
                    cm.ExecuteNonQuery();
                }

                query = " DELETE FROM DIET_PLAN WHERE CREATED_BY = + '" + Int32.Parse(textBox2.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " SELECT WP_ID FROM WORKOUT_PLAN WHERE CREATED_BY = + '" + Int32.Parse(textBox2.Text) + "' ";
                cm = new SqlCommand(query, conn);
                o1 = cm.ExecuteScalar();

                if (o1.ToString() != "")
                {
                    query = " DELETE FROM EXERCISE_CONTAIN WHERE WP_ID = + '" + Int32.Parse(o1.ToString()) + "' ";
                    cm = new SqlCommand(query, conn);
                    cm.ExecuteNonQuery();
                }

                query = " DELETE FROM WORKOUT_PLAN WHERE CREATED_BY = + '" + Int32.Parse(textBox2.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " DELETE FROM TRAINER WHERE TRAINER_ID = + '" + Int32.Parse(textBox2.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " DELETE FROM USER1 WHERE USERID = + '" + Int32.Parse(textBox2.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                MessageBox.Show("TRAINER DELETED!!");
                conn.Close();


            }
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString);

                conn.Open();

                string query = " DELETE FROM FEEDBACK WHERE MEMBER_ID = + '" + Int32.Parse(textBox1.Text) + "' ";
                SqlCommand cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " DELETE FROM TRAINING_APPOINTMENT WHERE MEMBER_ID = + '" + Int32.Parse(textBox1.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " SELECT DIETPLAN_ID FROM DIET_PLAN WHERE CREATED_BY = + '" + Int32.Parse(textBox1.Text) + "' ";
                cm = new SqlCommand(query, conn);
                object o1 = cm.ExecuteScalar();

                if (o1.ToString() != "")
                {
                    query = " DELETE FROM MEAL_CONTAIN WHERE DIETPLAN_ID = + '" + Int32.Parse(o1.ToString()) + "' ";
                    cm = new SqlCommand(query, conn);
                    cm.ExecuteNonQuery();
                }

                query = " DELETE FROM DIET_PLAN WHERE CREATED_BY = + '" + Int32.Parse(textBox1.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " SELECT WP_ID FROM WORKOUT_PLAN WHERE CREATED_BY = + '" + Int32.Parse(textBox1.Text) + "' ";
                cm = new SqlCommand(query, conn);
                o1 = cm.ExecuteScalar();

                if (o1.ToString() != "")
                {
                    query = " DELETE FROM EXERCISE_CONTAIN WHERE WP_ID = + '" + Int32.Parse(o1.ToString()) + "' ";
                    cm = new SqlCommand(query, conn);
                    cm.ExecuteNonQuery();
                }
                query = " DELETE FROM WORKOUT_PLAN WHERE CREATED_BY = + '" + Int32.Parse(textBox1.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " DELETE FROM MEMBER1 WHERE MEMBER_ID = + '" + Int32.Parse(textBox1.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " DELETE FROM USER1 WHERE USERID = + '" + Int32.Parse(textBox1.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                MessageBox.Show("MEMBER DELETED!!");
                conn.Close();


            }

        }
    }
}
