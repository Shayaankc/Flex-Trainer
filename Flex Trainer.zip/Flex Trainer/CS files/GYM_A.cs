﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DB_Project
{
    public partial class GYM_A : Form
    {
        public static GYM_A instance;
        public string userid;
        public int useri;
        public GYM_A()
        {
            InitializeComponent();
            instance = this;
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }
        public void membergridview()
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            string query = "SELECT * FROM OWNS_REQUEST";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable d1 = new DataTable();
            da.Fill(d1);
            membergymdatagridview.DataSource = d1;
            conn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionString);

            conn.Open();


            if (textBox1.Text != "")
            {
                string query = "SELECT NAME1 FROM OWNS_REQUEST WHERE OREQ_ID = + '" + Int32.Parse(textBox1.Text) + "' ";
                SqlCommand cm = new SqlCommand(query, conn);
                object o1 = cm.ExecuteScalar();
                string name = o1.ToString();

                query = "SELECT LOCATION1 FROM OWNS_REQUEST WHERE OREQ_ID = + '" + Int32.Parse(textBox1.Text) + "' ";
                cm = new SqlCommand(query, conn);
                o1 = cm.ExecuteScalar();
                string loc = o1.ToString();

                query = "INSERT INTO GYM VALUES('" + name + "', '" + loc + "')";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = "SELECT MAX(GYM_ID) FROM GYM";
                cm = new SqlCommand(query, conn);
                o1 = cm.ExecuteScalar();
                int gymid = Int32.Parse(o1.ToString());

                query = "SELECT OWNER_ID FROM OWNS_REQUEST WHERE OREQ_ID = + '" + Int32.Parse(textBox1.Text) + "' ";
                cm = new SqlCommand(query, conn);
                o1 = cm.ExecuteScalar();
                int oid = Int32.Parse(o1.ToString());



                query = "INSERT INTO OWNS VALUES('" + oid + "', '" + gymid + "')";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                button1_Click(sender, e);

                MessageBox.Show("Updated!!");
            }
            conn.Close();
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True"); // Connection String
            conn.Open();

            if (textBox1.Text != "")
            {
                string query = "DELETE FROM OWNS_REQUEST WHERE OWNS_REQUEST.OREQ_ID= +'" + Int32.Parse(textBox1.Text) + "'";

                SqlCommand cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Updated!!");

            }
        }
    }
}
