﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DB_Project
{
    public partial class RM_A : Form
    {
        public static RM_A instance;
        public string userid;
        public int useri;
        public RM_A()
        {
            InitializeComponent();
            instance = this;
        }
        public void membergridview()
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            string query = "SELECT * FROM GYM";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable d1 = new DataTable();
            da.Fill(d1);
            membergymdatagridview.DataSource = d1;
            conn.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";
                SqlConnection conn = new SqlConnection(connectionString);

                conn.Open();

                string query = " DELETE FROM WORKS_AT WHERE GYM_ID = + '" + Int32.Parse(textBox1.Text) + "' ";
                SqlCommand cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " DELETE FROM OWNS WHERE GYM_ID = + '" + Int32.Parse(textBox1.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " DELETE FROM GYM_REQUEST WHERE GYM_ID = + '" + Int32.Parse(textBox1.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " UPDATE MEMBER1 SET GYM_ID = NULL WHERE GYM_ID = +'" + Int32.Parse(textBox1.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                query = " DELETE FROM GYM WHERE GYM_ID = + '" + Int32.Parse(textBox1.Text) + "' ";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();



                MessageBox.Show("GYM MEMBERSHIP REVOKED!!");
                conn.Close();


            }
        }
    }
}
