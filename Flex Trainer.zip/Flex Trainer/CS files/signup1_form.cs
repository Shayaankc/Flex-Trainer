﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DB_Project
{
    public partial class signup1_form : Form
    {
        public signup1_form()
        {
            InitializeComponent();
            this.Size = new System.Drawing.Size(450, 660);
            label1.Hide();
            label2.Hide();
            label3.Hide();

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

      

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void gunaButton1_MouseEnter(object sender, EventArgs e)
        {
            label1.Show();
        }

        private void gunaButton1_MouseHover(object sender, EventArgs e)
        {
            label1.Show();
        }

        private void gunaButton1_MouseLeave(object sender, EventArgs e)
        {
            label1.Hide();
        }

   

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void gunaButton4_MouseEnter(object sender, EventArgs e)
        {
            label2.Show();
        }

        private void gunaButton4_MouseHover(object sender, EventArgs e)
        {
            label2.Show();
        }

        private void gunaButton4_MouseLeave(object sender, EventArgs e)
        {
            label2.Hide();
        }

        private void gunaButton2_MouseEnter(object sender, EventArgs e)
        {
            label3.Show();
        }

        private void gunaButton2_MouseHover(object sender, EventArgs e)
        {
            label3.Show();
        }

        private void gunaButton2_MouseLeave(object sender, EventArgs e)
        {
            label3.Hide();
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            this.Hide();

            signupm_form SFM = new signupm_form();

            SFM.Show();


        }

        private void gunaButton4_Click(object sender, EventArgs e)
        {
            this.Hide();
            signupT_form o1 = new signupT_form();
            o1.Show();
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            this.Hide();
            signupO_form o1 = new signupO_form();
            o1.Show();
        }
    }
}
