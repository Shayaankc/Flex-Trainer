﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace dbproject
{
    public partial class membercreatediet : Form
    {
        public static membercreatediet instance;
        public string userid;
        public int useri;
        public membercreatediet()
        {
            InitializeComponent();
            instance = this;
            membergymdatagridview.CellClick += membergymdatagridview_CellClick;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
           
        }
        private void membergymdatagridview_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int id = Convert.ToInt32(membergymdatagridview.Rows[e.RowIndex].Cells["ID"].Value);

            string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            string query = "SELECT CARBS FROM MEAL WHERE MEAL_ID = + '" + id + "' ";
            SqlCommand cm = new SqlCommand(query, conn);
            object o1 = cm.ExecuteScalar();
            string carbs = o1.ToString();

            query = "SELECT PROT FROM MEAL WHERE MEAL_ID = + '" + id + "' ";
            cm = new SqlCommand(query, conn);
            o1 = cm.ExecuteScalar();
            string protein = o1.ToString();

            query = "SELECT CAL FROM MEAL WHERE MEAL_ID = + '" + id + "' ";
            cm = new SqlCommand(query, conn);
            o1 = cm.ExecuteScalar();
            string cal = o1.ToString();

            query = "SELECT FATS FROM MEAL WHERE MEAL_ID = + '" + id + "' ";
            cm = new SqlCommand(query, conn);
            o1 = cm.ExecuteScalar();
            string fat = o1.ToString();

            query = "SELECT ALERGEN FROM MEAL WHERE MEAL_ID = + '" + id + "' ";
            cm = new SqlCommand(query, conn);
            o1 = cm.ExecuteScalar();
            string allergy = o1.ToString();

            conn.Close();


            string info = "Info: Calories: " + cal + "  Carbs: " + carbs + "  Proteins: " + protein + "  Fats: " + fat;
            label10.Text = info;
            label11.Text = "ALLERGEN: " + allergy;

        }

        public void membergridview()
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            string query = "SELECT MEAL_ID AS ID,NAME1 AS NAME, TIME1 AS TIME, DESCRIPTION1 AS DESCRIPTION FROM MEAL";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable d1 = new DataTable();
            da.Fill(d1);
            membergymdatagridview.DataSource = d1;
            conn.Close();
        }

       

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True"); // Connection String
            conn.Open();
            SqlCommand cm;

            string name = textBox1.Text;
            string type = textBox2.Text;
            string description = textBox3.Text;
            string goal = textBox7.Text;
            string m1 = textBox4.Text;
            string m2 = textBox5.Text;
            string m3 = textBox6.Text;
            if (name != "" && type != "" && description != "" && goal != "" && m1 != "")
            {
                int i1 = Int32.Parse(m1);

                string query = "INSERT INTO DIET_PLAN (CREATED_BY, NAME1, TYPE1, GOAL, DESCRIPTION1) VALUES (" + useri + ", '" + name + "', '" + type + "', '" + goal + "', '" + description + "')";

                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();


                query = "SELECT MAX(DIETPLAN_ID) FROM DIET_PLAN";
                cm = new SqlCommand(query, conn);
                object o1 = cm.ExecuteScalar();
                int dp_id = Int32.Parse(o1.ToString());

                query = "INSERT INTO MEAL_CONTAIN (DIETPLAN_ID, MEAL_ID) VALUES (" + dp_id + ", " + i1 + ")";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();

                if (m2 != "")
                {
                    i1 = Int32.Parse(m2);
                    query = "INSERT INTO MEAL_CONTAIN (DIETPLAN_ID, MEAL_ID) VALUES (" + dp_id + ", " + i1 + ")";
                    cm = new SqlCommand(query, conn);
                    cm.ExecuteNonQuery();
                }
                if (m3 != "")
                {
                    i1 = Int32.Parse(m3);
                    query = "INSERT INTO MEAL_CONTAIN (DIETPLAN_ID, MEAL_ID) VALUES (" + dp_id + ", " + i1 + ")";
                    cm = new SqlCommand(query, conn);
                    cm.ExecuteNonQuery();
                }



                query = "UPDATE MEMBER1 SET DP_ID = +'" + dp_id + "' WHERE MEMBER_ID = +'" + Int32.Parse(userid) + "'";
                cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();
                conn.Close();



                MessageBox.Show(dp_id + "Updated!!");
                this.Hide();
            }
            else
                MessageBox.Show("Please fill all required boxes, (Only Meal2 and Meal3 are optional)");
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}

