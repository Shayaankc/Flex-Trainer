﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DB_Project
{
    public partial class loging_form : Form
    {
        int count = 0;
        public loging_form()
        {
            InitializeComponent();

        }

        private void gunaTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void gunaTextBox2_TextChanged(object sender, EventArgs e)
        {
            gunaTextBox2.PasswordChar = '●';
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True"); //Connection String
            conn.Open();
            SqlCommand cm;

            string un = gunaTextBox1.Text;
            string pass = gunaTextBox2.Text;
            string query = "Select PASSWORD1 from USER1 where USERNAME =  + '" + un + "' ";
            cm = new SqlCommand(query, conn);

            object o1 = cm.ExecuteScalar();

            if (count < 3)
            {
                if (o1 != null)
                {
                    if (o1.ToString() == pass)
                    {
                        this.Hide();
                        query = "Select USERTYPE from USER1 where USERNAME =  + '" + un + "' ";
                        cm = new SqlCommand(query, conn);

                        object o2 = cm.ExecuteScalar();

                        if (o2.ToString() == "MEMBER")
                        {
                            query = "Select USERID from USER1 where USERNAME =  + '" + un + "' ";
                            cm = new SqlCommand(query, conn);

                            o2 = cm.ExecuteScalar();

                            member_main m1 = new member_main();

                            member_main.instance.userid = o2.ToString();
                            m1.Show();
                        }
                        if (o2.ToString() == "TRAINER")
                        {
                            query = "Select USERID from USER1 where USERNAME =  + '" + un + "' ";
                            cm = new SqlCommand(query, conn);

                            o2 = cm.ExecuteScalar();

                            trainer_main m1 = new trainer_main();
                            trainer_main.instance.userid = o2.ToString();
                            m1.Show();
                        }
                        if (o2.ToString() == "OWNER")
                        {
                            query = "Select USERID from USER1 where USERNAME =  + '" + un + "' ";
                            cm = new SqlCommand(query, conn);

                            o2 = cm.ExecuteScalar();

                            owner_main m1 = new owner_main();
                            owner_main.instance.userid = o2.ToString();
                            m1.Show();
                        }
                        if (o2.ToString() == "ADMIN")
                        {
                            query = "Select USERID from USER1 where USERNAME =  + '" + un + "' ";
                            cm = new SqlCommand(query, conn);

                            o2 = cm.ExecuteScalar();

                            admin_main m1 = new admin_main();
                            admin_main.instance.userid = o2.ToString();
                            m1.Show();
                        }
                    }
                    else
                    {
                        MessageBox.Show("INCORRECT PASS");
                        count++;
                    }
                }
                else
                {
                    MessageBox.Show("ENTER A VALID USERNAME");
                }
            }
            else
                MessageBox.Show("PLEASE CONTINUE TO THE SIGN-UP PAGE");


            cm.Dispose();
            conn.Close();
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            this.Hide();

            signup1_form SF1 = new signup1_form();

            SF1.Show();


        }
    }
}
