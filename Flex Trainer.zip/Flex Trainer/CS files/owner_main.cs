﻿using dbproject;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DB_Project
{
    public partial class owner_main : Form
    {
        Workout_M Workout_M;
        memberappointment book_Trainer_M;
        memberfeedback memberfeedback;
        memberdiet memberdiet;

        public static owner_main instance;
        public string userid;


        public owner_main()
        {
            InitializeComponent();
            this.Size = new System.Drawing.Size(800, 590);
            instance = this;
        }

        public void loadform(object Form)
        {
            if (this.main_panel.Controls.Count > 0)
            {
                Form previousForm = this.main_panel.Controls[0] as Form;
                previousForm.Close();
            }
            Form f = Form as Form;
            f.TopLevel = false;
            f.TopLevel = false;
            f.Dock = DockStyle.Fill;
            this.main_panel.Controls.Add(f);
            this.main_panel.Tag = f;
            f.Show();
        }

        private void member_main_Load(object sender, EventArgs e)
        {

        }

        bool sidbarexpand = true;
        private void transitiontimer_Tick(object sender, EventArgs e)
        {
            if (sidbarexpand)
            {
                side_bar.Width -= 7;

                if (side_bar.Width <= 70)
                {
                    sidbarexpand = false;
                    transitiontimer.Stop();

                    DPP.Width = side_bar.Width;
                    BTP.Width = side_bar.Width;
                    FBP.Width = side_bar.Width;
                }
            }
            else
            {
                side_bar.Width += 7;

                if (side_bar.Width >= 200)
                {
                    sidbarexpand = true;
                    transitiontimer.Stop();

                    DPP.Width = side_bar.Width;
                    BTP.Width = side_bar.Width;
                    FBP.Width = side_bar.Width;
                }
            }
        }

        private void TOP_BUTTON_Click(object sender, EventArgs e)
        {
            transitiontimer.Start();

        }

        private void FBB_Click(object sender, EventArgs e)
        {
            NewTrain_O o1 = new NewTrain_O();
            NewTrain_O.instance.userid = userid;
            NewTrain_O.instance.useri = Int32.Parse(userid);
            NewTrain_O.instance.membergridview();
            loadform(o1);
        }


        private void BTB_Click(object sender, EventArgs e)
        {
            AccSet_O o1 = new AccSet_O();
            AccSet_O.instance.userid = userid;
            AccSet_O.instance.useri = Int32.Parse(userid);
            AccSet_O.instance.membergridview();
            AccSet_O.instance.membergridview2();
            loadform(o1);

            //loadform(new memberappointment());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            O_report_M o1 = new O_report_M();
            O_report_M.instance.useri = Int32.Parse(userid);
            loadform(o1);
        }

        private void DPB_Click(object sender, EventArgs e)
        {
            O_report_T o1 = new O_report_T();
            O_report_T.instance.useri = Int32.Parse(userid);
            loadform(o1);
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            GYM_O o1 = new GYM_O();
            GYM_O.instance.userid = userid;
            GYM_O.instance.useri = Int32.Parse(userid);
            loadform(o1);
        }
    }
}
