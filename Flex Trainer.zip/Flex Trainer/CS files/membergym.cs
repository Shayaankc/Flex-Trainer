﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace dbproject
{
    public partial class membergym : Form
    {
        public static membergym instance;
        public string userid;
        public membergym()
        {
            InitializeComponent();
            instance = this;
            membergridview();
        }

        /*
            
            MessageBox.Show(useri.ToString());
        */


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void membergridview()
        {
            SqlConnection conn = new SqlConnection(" Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            string query = "SELECT GYM_ID AS ID, NAME1 AS NAME, LOCATION1 AS LOC FROM GYM";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable d1 = new DataTable();
            da.Fill(d1);
            membergymdatagridview.DataSource = d1;
            conn.Close();
        }
        public void currlabel()
        {
            string connectionString = "Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True";

            SqlConnection conn = new SqlConnection(connectionString);

            conn.Open();

            string query = "SELECT * FROM GYM JOIN MEMBER1 ON GYM.GYM_ID = MEMBER1.GYM_ID WHERE MEMBER1.MEMBER_ID = +'" + Int32.Parse(userid) + "' ";
            SqlCommand cm = new SqlCommand(query, conn);


            SqlDataReader reader = cm.ExecuteReader();

            if (reader.Read())
            {
                int gymId = reader.GetInt32(reader.GetOrdinal("GYM_ID"));
                string gymName = reader.GetString(reader.GetOrdinal("NAME1"));

                label3.Text = "Current Gym: " + $"GYM ID: {gymId}, GYM Name: {gymName}";
            }
            else
            {
                label3.Text = "The User Is Not In Any GYM";
            }

            reader.Close();
            conn.Close();

        }

        private void membergym_Load(object sender, EventArgs e)
        {

        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            
                SqlConnection conn = new SqlConnection(" Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
                conn.Open();
                SqlCommand cm;


                int useri = Int32.Parse(userid);
                string choice = textBox1.Text;
                if (choice != "")
                {
                    int c = Int32.Parse(choice);

                    string query = "UPDATE MEMBER1 SET GYM_ID = +'" + c + "' WHERE MEMBER_ID = +'" + useri + "'";
                    cm = new SqlCommand(query, conn);
                    cm.ExecuteNonQuery();

                    query = "UPDATE MEMBER1 SET JOINING_DATE = GETDATE() WHERE MEMBER_ID = +'" + useri + "'";
                    cm = new SqlCommand(query, conn);
                    cm.ExecuteNonQuery();

                    query = "UPDATE MEMBER1 SET WP_ID = NULL WHERE MEMBER_ID = +'" + useri + "'";
                    cm = new SqlCommand(query, conn);
                    cm.ExecuteNonQuery();

                    query = "UPDATE MEMBER1 SET DP_ID = NULL WHERE MEMBER_ID = +'" + useri + "'";
                    cm = new SqlCommand(query, conn);
                    cm.ExecuteNonQuery();

                    query = "DELETE FROM TRAINING_APPOINTMENT WHERE MEMBER_ID= +'" + useri + "'";
                    cm = new SqlCommand(query, conn);
                    cm.ExecuteNonQuery();

                    conn.Close();

                    MessageBox.Show("Updated!!");
                }


       

        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {

        }
    }
}
