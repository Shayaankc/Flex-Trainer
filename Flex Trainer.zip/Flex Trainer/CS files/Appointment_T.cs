﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DB_Project
{
    public partial class Appointment_T : Form
    {
        public static Appointment_T instance;
        public string userid;
        public int useri;
        public Appointment_T()
        {
            InitializeComponent();
            instance = this;
            dateTimePicker1.Hide();
            dateTimePicker2.Hide();
            label4.Hide();
            label6.Hide();
            gunaButton3.Hide();
        }
        public void membergridview()
        {
            SqlConnection conn = new SqlConnection(" Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True");
            conn.Open();
            string query = "SELECT TA_ID AS ID, MEMBER_ID AS MEMBERID, DATE1 AS DATE, TIME1 AS TIME FROM TRAINING_APPOINTMENT WHERE TRAINING_APPOINTMENT.TRAINER_ID= +'" + useri + "'";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            DataTable d1 = new DataTable();
            da.Fill(d1);
            membergymdatagridview.DataSource = d1;
            conn.Close();
        }


        private void gunaButton1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True"); // Connection String
            conn.Open();

            string c = textBox1.Text;
            if (!string.IsNullOrEmpty(c))
            {
                string query = "DELETE FROM TRAINING_APPOINTMENT WHERE TRAINING_APPOINTMENT.TA_ID= +'" + Int32.Parse(c) + "'";

                SqlCommand cm = new SqlCommand(query, conn);
                cm.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Updated!!");

            }
        }

        private void gunaButton2_Click(object sender, EventArgs e)
        {
            gunaButton1.Hide();
            gunaButton2.Hide();
            dateTimePicker1.Show();
            dateTimePicker2.Show();
            label4.Show();
            label6.Show();
            gunaButton3.Show();
        }

        private void gunaButton3_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=MINION\\SQLEXPRESS;Initial Catalog=flex_trainer;Integrated Security=True"); // Connection String
            conn.Open();

            string c = textBox1.Text;
            if (!string.IsNullOrEmpty(c))
            {
                string date = dateTimePicker1.Value.ToString("yyyy-MM-dd");
                string time = dateTimePicker2.Value.ToString("HH:mm:ss");

                string query = "UPDATE TRAINING_APPOINTMENT SET DATE1 = @Date, TIME1 = @Time WHERE TA_ID = +'" + Int32.Parse(c) + "'";

                SqlCommand cm = new SqlCommand(query, conn);
                cm.Parameters.AddWithValue("@Date", date);
                cm.Parameters.AddWithValue("@Time", time);

                cm.ExecuteNonQuery();
                conn.Close();

                MessageBox.Show("Updated!!");

            }

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
